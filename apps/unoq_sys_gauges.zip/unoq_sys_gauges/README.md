# UNO Q App — System Gauges Web Dashboard (Beautiful Circle Meters)

This is a **UNO Q App Lab app** (installs with `arduino-app-cli`) that runs a web server on the UNO Q and serves a
**beautiful GUI** with:
- Circle gauges: CPU, RAM, Disk, Load, Network peak
- Up to 3 temperature gauges (auto-detected thermal zones)
- Full system specs panel (lscpu/free/df/ip + sensors best effort)

✅ Pure Python (standard library only). No `pip` installs.

---

## Install (on the UNO Q)

```bash
arduino-app-cli app install ./unoq_sys_gauges_app.zip
arduino-app-cli app start unoq_sys_gauges
arduino-app-cli app logs  unoq_sys_gauges
```

Browse:
- http://<UNOQ_IP>:8080

Stop:
```bash
arduino-app-cli app stop unoq_sys_gauges
```

---

## If it shows "broken"
Cache corruption happens. Clean cache then start again:

```bash
arduino-app-cli app clean-cache unoq_sys_gauges
arduino-app-cli app start unoq_sys_gauges
```
