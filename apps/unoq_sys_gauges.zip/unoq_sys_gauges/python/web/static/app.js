const $ = (q) => document.querySelector(q);

function clamp(n, a, b){ return Math.max(a, Math.min(b, n)); }

function setRing(id, percent, big, label, detail, klass){
  percent = clamp(percent, 0, 100);
  const ring = document.getElementById(id);
  if (!ring) return;

  const fg = ring.querySelector(".ring-fg");
  const bigEl = ring.querySelector(".big");
  const smallEl = ring.querySelector(".small");
  const tinyEl = ring.querySelector(".tiny");

  // circumference based on r=42 in SVG
  const r = 42;
  const c = 2 * Math.PI * r;
  const dash = (percent/100) * c;
  fg.style.strokeDasharray = `${dash} ${c-dash}`;

  // classes (only safe tokens)
  fg.classList.remove("warn","bad");
  if (klass) fg.classList.add(klass);

  if (bigEl) bigEl.textContent = big ?? "--";
  if (smallEl) smallEl.textContent = label ?? "";
  if (tinyEl) tinyEl.textContent = detail ?? "";
}

function rateClassTemp(tempC){
  if (tempC == null) return "";
  if (tempC >= 85) return "bad";
  if (tempC >= 75) return "warn";
  return "";
}

function fmtBytes(b){
  if (b == null) return "--";
  const u = ["B","KB","MB","GB","TB"];
  let i=0;
  while (b>=1024 && i<u.length-1){ b/=1024; i++; }
  return `${b.toFixed(i===0?0:1)} ${u[i]}`;
}

function fmtBitsPerSec(bps){
  if (bps == null) return "--";
  const u = ["bps","Kbps","Mbps","Gbps"];
  let i=0;
  while (bps>=1000 && i<u.length-1){ bps/=1000; i++; }
  return `${bps.toFixed(i===0?0:1)} ${u[i]}`;
}

async function refresh(){
  try{
    const r = await fetch("/api/status");
    const s = await r.json();

    // Pills
    $("#pillHost").textContent = s.host?.hostname ?? "host";
    $("#pillIP").textContent = `IP: ${s.net?.primary_ip ?? "--"}`;
    $("#pillUptime").textContent = `Uptime: ${s.uptime_human ?? "--"}`;
    $("#pillTime").textContent = new Date(s.ts*1000).toLocaleTimeString();

    // Gauges
    setRing("g_cpu",
      s.cpu?.usage_percent ?? 0,
      `${Math.round(s.cpu?.usage_percent ?? 0)}%`,
      "CPU",
      "",
      ""
    );

    setRing("g_mem",
      s.mem?.used_percent ?? 0,
      `${Math.round(s.mem?.used_percent ?? 0)}%`,
      "RAM",
      `${fmtBytes(s.mem?.used_bytes)}/${fmtBytes(s.mem?.total_bytes)}`,
      ""
    );

    setRing("g_disk",
      s.disk?.used_percent ?? 0,
      `${Math.round(s.disk?.used_percent ?? 0)}%`,
      "Disk /",
      `${fmtBytes(s.disk?.used_bytes)}/${fmtBytes(s.disk?.total_bytes)}`,
      ""
    );

    // Load normalized (1m load vs logical cores)
    const cores = s.host?.cpu_cores_logical ?? 1;
    const load1 = s.load?.la1 ?? 0;
    const loadPct = clamp((load1/cores)*100, 0, 200);
    setRing("g_load",
      clamp(loadPct, 0, 100),
      load1.toFixed(2),
      "Load(1m)",
      `cores ${cores}`,
      loadPct>120 ? "warn" : ""
    );

    // Network speed gauge uses max 100 Mbps scale by default
    const rx = s.net?.rx_bps ?? 0;
    const tx = s.net?.tx_bps ?? 0;
    const peak = Math.max(rx, tx);
    const scaleBps = (s.net?.scale_mbps ?? 100) * 1_000_000;
    const netPct = clamp((peak/scaleBps)*100, 0, 100);
    setRing("g_net",
      netPct,
      `${Math.round(netPct)}%`,
      "Net peak",
      `${fmtBitsPerSec(peak)}`,
      netPct>80 ? "warn" : ""
    );

    // Temps: render up to 3 temp gauges
    // Temps: render up to 3 temp gauges// Temps: render up to 3 temp gauges
    const temps = s.temps?.zones ?? [];
    const slots = ["t1","t2","t3"];
    for (let i=0; i<slots.length; i++){
      const z = temps[i];
      const id = `g_${slots[i]}`;
      if (!z){
        setRing(id, 0, "--", "Temp", "N/A", "");
        continue;
      }
      const tc = z.temp_c;
      const pct = tc == null ? 0 : clamp((tc/100)*100, 0, 100);
      setRing(id, pct, tc==null ? "--" : `${tc.toFixed(1)}°C`, z.type || `zone${z.zone}`, "Temp", rateClassTemp(tc));
      const fg = document.getElementById(id)?.querySelector(".ring-fg");
      if (fg) fg.classList.add("temp");
    }

    // Key/Value panel
    const kv = [
      ["CPU", s.host?.cpu_model ?? "--"],
      ["Cores", `${s.host?.cpu_cores_logical ?? "--"} logical / ${s.host?.cpu_cores_physical ?? "--"} physical`],
      ["OS", s.host?.os ?? "--"],
      ["Kernel", s.host?.kernel ?? "--"],
      ["Arch", s.host?.arch ?? "--"],
      ["Load (1/5/15)", `${(s.load?.la1??0).toFixed(2)} / ${(s.load?.la5??0).toFixed(2)} / ${(s.load?.la15??0).toFixed(2)}`],
      ["RAM", `${fmtBytes(s.mem?.total_bytes)} total`],
      ["Disk /", `${fmtBytes(s.disk?.total_bytes)} total`],
      ["Net RX/TX", `${fmtBitsPerSec(rx)} / ${fmtBitsPerSec(tx)}`],
    ];
    const box = $("#kvBox");
    box.innerHTML = "";
    for (const [k,v] of kv){
      const row = document.createElement("div");
      row.className = "row";
      row.innerHTML = `<div class="k">${k}</div><div class="v" title="${String(v).replaceAll('"','&quot;')}">${v}</div>`;
      box.appendChild(row);
    }

    // Specs raw
    $("#specs").textContent = s.specs_text ?? "--";

  }catch(e){
    console.error(e);
  }
}

refresh();
setInterval(refresh, 1000);
