from arduino.app_utils import App
import time
from server import serve_in_background

def loop():
    time.sleep(60)

def main():
    serve_in_background(host="0.0.0.0", port=8080)
    App.run(user_loop=loop)

if __name__ == "__main__":
    main()
