#!/usr/bin/env python3
# UNO Q App Lab: System Gauges Web Dashboard (no deps)

from __future__ import annotations
import json
import os
import platform
import shutil
import socket
import subprocess
import threading
import time
from dataclasses import dataclass
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, Any, Tuple, Optional, List

ROOT = Path(__file__).resolve().parent / "web"
STATIC = ROOT / "static"
INDEX = ROOT / "index.html"

def _run(cmd: List[str]) -> str:
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True)
        return out.strip()
    except Exception:
        return ""

def _read_text(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""

def _read_int(p: Path) -> Optional[int]:
    try:
        return int(_read_text(p).strip())
    except Exception:
        return None

def _uptime_seconds() -> Optional[float]:
    try:
        with open("/proc/uptime","r",encoding="utf-8") as f:
            return float(f.read().split()[0])
    except Exception:
        return None

def _human_uptime(sec: Optional[float]) -> str:
    if sec is None:
        return "--"
    sec = int(sec)
    d, rem = divmod(sec, 86400)
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    if d > 0:
        return f"{d}d {h:02d}h {m:02d}m"
    if h > 0:
        return f"{h}h {m:02d}m {s:02d}s"
    return f"{m}m {s:02d}s"

def _meminfo() -> Dict[str, int]:
    out: Dict[str, int] = {}
    try:
        with open("/proc/meminfo","r",encoding="utf-8") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    key = parts[0].rstrip(":")
                    kb = int(parts[1])
                    out[key] = kb * 1024
    except Exception:
        pass
    return out

def _disk_usage(path: str = "/") -> Dict[str, Any]:
    try:
        du = shutil.disk_usage(path)
        used_pct = (du.used / du.total * 100.0) if du.total else 0.0
        return {"path": path, "total_bytes": du.total, "used_bytes": du.used, "free_bytes": du.free, "used_percent": used_pct}
    except Exception:
        return {"path": path, "total_bytes": None, "used_bytes": None, "free_bytes": None, "used_percent": 0.0}

def _loadavg() -> Tuple[float,float,float]:
    try:
        return os.getloadavg()
    except Exception:
        return (0.0,0.0,0.0)

def _cpu_model() -> str:
    try:
        with open("/proc/cpuinfo","r",encoding="utf-8") as f:
            for line in f:
                if ":" in line and ("model name" in line or "Hardware" in line or "Processor" in line):
                    return line.split(":",1)[1].strip()
    except Exception:
        pass
    return platform.processor() or "CPU"

def _cpu_cores() -> Tuple[int,int]:
    logical = os.cpu_count() or 1
    physical = 0
    lscpu = _run(["lscpu"])
    cps = socks = 0
    if lscpu:
        for ln in lscpu.splitlines():
            lo = ln.lower()
            if lo.startswith("core(s) per socket:"):
                try: cps = int(ln.split(":",1)[1].strip())
                except Exception: cps = 0
            if lo.startswith("socket(s):"):
                try: socks = int(ln.split(":",1)[1].strip())
                except Exception: socks = 0
    try:
        physical = cps * socks
    except Exception:
        physical = 0
    if physical <= 0:
        physical = logical
    return logical, physical

def _primary_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 53))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "--"

def _net_bytes() -> Tuple[int,int]:
    rx = tx = 0
    try:
        with open("/proc/net/dev","r",encoding="utf-8") as f:
            for line in f:
                if ":" not in line:
                    continue
                iface, data = line.split(":",1)
                iface = iface.strip()
                if iface == "lo":
                    continue
                cols = data.split()
                if len(cols) >= 9:
                    rx += int(cols[0])
                    tx += int(cols[8])
    except Exception:
        pass
    return rx, tx

def _thermal_zones() -> List[Dict[str, Any]]:
    zones = []
    base = Path("/sys/class/thermal")
    try:
        for z in sorted(base.glob("thermal_zone*")):
            t = _read_text(z / "type").strip()
            temp_m = _read_int(z / "temp")
            temp_c = None
            if temp_m is not None:
                temp_c = temp_m / 1000.0 if temp_m > 200 else float(temp_m)
            zones.append({"zone": z.name.replace("thermal_zone",""), "type": t or z.name, "temp_c": temp_c})
    except Exception:
        pass
    zones.sort(key=lambda d: (d["temp_c"] is None, -(d["temp_c"] or 0)))
    return zones

@dataclass
class CpuStat:
    total: int
    idle: int

def _read_cpu_stat() -> CpuStat:
    try:
        with open("/proc/stat","r",encoding="utf-8") as f:
            for line in f:
                if line.startswith("cpu "):
                    parts = line.split()
                    nums = list(map(int, parts[1:]))
                    total = sum(nums)
                    idle = nums[3] + (nums[4] if len(nums) > 4 else 0)
                    return CpuStat(total=total, idle=idle)
    except Exception:
        pass
    return CpuStat(total=0, idle=0)

class State:
    def __init__(self) -> None:
        self.last_cpu = _read_cpu_stat()
        self.last_net = _net_bytes()
        self.last_ts = time.time()
        self.specs_text = self._build_specs_text()

    def _build_specs_text(self) -> str:
        bits = []
        bits.append(f"Hostname: {socket.gethostname()}")
        bits.append(f"OS: {platform.platform()}")
        bits.append(f"Kernel: {platform.release()}")
        bits.append(f"Arch: {platform.machine()}")
        bits.append("")
        bits.append("== CPU ==")
        bits.append(_run(["lscpu"]) or _cpu_model())
        bits.append("")
        bits.append("== Memory ==")
        bits.append(_run(["free","-h"]) or "")
        bits.append("")
        bits.append("== Disk ==")
        bits.append(_run(["df","-h"]) or "")
        bits.append("")
        bits.append("== Network ==")
        bits.append(_run(["ip","addr"]) or "")
        bits.append("")
        bits.append("== Sensors (best effort) ==")
        bits.append(_run(["sensors"]) or "(lm-sensors not installed)")
        return "\n".join([b for b in bits if b is not None])

    def cpu_usage_percent(self) -> float:
        now = _read_cpu_stat()
        prev = self.last_cpu
        self.last_cpu = now
        dt = (now.total - prev.total)
        di = (now.idle - prev.idle)
        if dt <= 0:
            return 0.0
        used = (dt - di) / dt * 100.0
        return max(0.0, min(100.0, used))

    def net_rates(self) -> Tuple[float,float]:
        rx, tx = _net_bytes()
        prx, ptx = self.last_net
        now = time.time()
        dt = max(0.2, now - self.last_ts)
        self.last_ts = now
        self.last_net = (rx, tx)
        return ((rx - prx) / dt * 8.0, (tx - ptx) / dt * 8.0)  # bits/sec

STATE = State()

def build_status() -> Dict[str, Any]:
    ts = time.time()
    up = _uptime_seconds()
    la1, la5, la15 = _loadavg()
    cpu_usage = STATE.cpu_usage_percent()

    mi = _meminfo()
    total = mi.get("MemTotal", 0)
    avail = mi.get("MemAvailable", mi.get("MemFree", 0))
    used = max(0, total - avail)
    mem_pct = (used / total * 100.0) if total else 0.0

    disk = _disk_usage("/")
    rx_bps, tx_bps = STATE.net_rates()
    logical, physical = _cpu_cores()

    host = {
        "hostname": socket.gethostname(),
        "os": platform.platform(),
        "kernel": platform.release(),
        "arch": platform.machine(),
        "cpu_model": _cpu_model(),
        "cpu_cores_logical": logical,
        "cpu_cores_physical": physical,
    }

    return {
        "ts": ts,
        "uptime_seconds": up,
        "uptime_human": _human_uptime(up),
        "load": {"la1": la1, "la5": la5, "la15": la15},
        "cpu": {"usage_percent": cpu_usage},
        "mem": {"total_bytes": total, "used_bytes": used, "avail_bytes": avail, "used_percent": mem_pct},
        "disk": disk,
        "net": {"primary_ip": _primary_ip(), "rx_bps": max(0.0, rx_bps), "tx_bps": max(0.0, tx_bps), "scale_mbps": 100},
        "host": host,
        "temps": {"zones": _thermal_zones()},
        "specs_text": STATE.specs_text,
    }

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path: str) -> str:
        path = path.split("?",1)[0].split("#",1)[0]
        if path == "/":
            return str(INDEX)
        if path == "/index.html":
            return str(INDEX)
        if path.startswith("/static/"):
            return str(STATIC / path[len("/static/"):])
        return str(ROOT / "__nope__")

    def do_GET(self) -> None:
        if self.path.startswith("/api/status"):
            payload = build_status()
            data = json.dumps(payload).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path == "/" or self.path == "/index.html" or self.path.startswith("/static/"):
            return super().do_GET()

        self.send_response(404)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(b"404 Not Found\n")

def serve_in_background(host: str = "0.0.0.0", port: int = 8080) -> None:
    httpd = ThreadingHTTPServer((host, port), Handler)
    def _run_forever():
        ip = _primary_ip()
        print(f"[sysgauges] Serving on http://{host}:{port}  (open: http://{ip}:{port})")
        httpd.serve_forever()
    t = threading.Thread(target=_run_forever, daemon=True)
    t.start()
