#!/usr/bin/env python3
import json
import threading
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict

PYTHON_DIR = Path(__file__).resolve().parent
APP_DIR = PYTHON_DIR.parent
DATA_DIR = APP_DIR / "data"
CONFIG_PATH = APP_DIR / "config.json"
CACHE_PATH = DATA_DIR / "weather_cache.json"
USAGE_PATH = DATA_DIR / "usage.json"
HISTORY_PATH = DATA_DIR / "weather_history.jsonl"
SKETCH_PATH = APP_DIR / "sketch" / "sketch.ino"

DEFAULT_CONFIG: Dict[str, Any] = {
    "weather_api_key": "REPLACE_WITH_YOUR_NEW_KEY",
    "zip_code": "75081",
    "location_query": "",
    "units": "imperial",
    "refresh_seconds": 30,
    "port": 8080,
    "forecast_days": 3,
    "show_alerts": True,
    "show_air_quality": True,
    "history_interval_seconds": 3600,
    "max_history_entries": 336,
    "monthly_call_budget": 2000000,
    "theme": "arctic-blue",
    "location_label_override": "",
    "manual_refresh_cooldown_seconds": 15,
    "bind_host": "0.0.0.0",
    "led_matrix_brightness": 180,
    "led_matrix_scroll_ms": 55,
}

THEMES: Dict[str, Dict[str, str]] = {
    "retro-crt": {
        "name": "Retro CRT",
        "bg": "#03150f",
        "panel": "#09241a",
        "panel2": "#0d2e22",
        "text": "#94ffb6",
        "muted": "#54d47a",
        "accent": "#d7ff7b",
        "accent_text": "#071108",
        "border": "#1d6b3d",
        "alert": "#ff8f8f",
        "ok": "#8cffc9",
        "link": "#d7ff7b",
    },
    "arctic-blue": {
        "name": "Arctic Blue",
        "bg": "#081521",
        "panel": "#102434",
        "panel2": "#163248",
        "text": "#d9f2ff",
        "muted": "#8ebfd8",
        "accent": "#72d3ff",
        "accent_text": "#081521",
        "border": "#2e607d",
        "alert": "#ffd1d1",
        "ok": "#b9ffe6",
        "link": "#9fe2ff",
    },
    "ocean-blue": {
        "name": "Ocean Blue",
        "bg": "#06101b",
        "panel": "#0d2033",
        "panel2": "#11314d",
        "text": "#d9eaff",
        "muted": "#99b7df",
        "accent": "#4fa8ff",
        "accent_text": "#06101b",
        "border": "#285482",
        "alert": "#ffd0d0",
        "ok": "#b5ffe8",
        "link": "#82c5ff",
    },
    "amber-terminal": {
        "name": "Amber Terminal",
        "bg": "#120a02",
        "panel": "#231507",
        "panel2": "#311e0c",
        "text": "#ffd48a",
        "muted": "#dba65e",
        "accent": "#ffb347",
        "accent_text": "#120a02",
        "border": "#815322",
        "alert": "#ffd2aa",
        "ok": "#fff0b3",
        "link": "#ffd48a",
    },
    "midnight": {
        "name": "Midnight",
        "bg": "#0a0d18",
        "panel": "#171d2f",
        "panel2": "#212943",
        "text": "#edf0ff",
        "muted": "#a6b1d9",
        "accent": "#a78bfa",
        "accent_text": "#0a0d18",
        "border": "#454c77",
        "alert": "#ffcadb",
        "ok": "#c9ffd9",
        "link": "#c8b6ff",
    },
    "sky-blue": {
        "name": "Sky Blue",
        "bg": "#e8f4ff",
        "panel": "#ffffff",
        "panel2": "#f3f9ff",
        "text": "#16324a",
        "muted": "#50708b",
        "accent": "#45a3ff",
        "accent_text": "#ffffff",
        "border": "#9cc9f0",
        "alert": "#7b2234",
        "ok": "#0b6b48",
        "link": "#1467b5",
    },
    "storm": {
        "name": "Storm",
        "bg": "#11161d",
        "panel": "#1c2630",
        "panel2": "#243240",
        "text": "#ecf3fb",
        "muted": "#9db0c1",
        "accent": "#7ca8ff",
        "accent_text": "#11161d",
        "border": "#4a5d72",
        "alert": "#ffc7c7",
        "ok": "#c5ffed",
        "link": "#b2c9ff",
    },
    "ice": {
        "name": "Ice",
        "bg": "#eefcff",
        "panel": "#ffffff",
        "panel2": "#f6feff",
        "text": "#123243",
        "muted": "#5b7a89",
        "accent": "#69d2ff",
        "accent_text": "#083041",
        "border": "#b7e8f6",
        "alert": "#7a2140",
        "ok": "#0d6c5d",
        "link": "#087cb0",
    },
    "desert-amber": {
        "name": "Desert Amber",
        "bg": "#1b1208",
        "panel": "#2b1d10",
        "panel2": "#3a2816",
        "text": "#ffe2b8",
        "muted": "#d7b07e",
        "accent": "#ffbf69",
        "accent_text": "#1b1208",
        "border": "#8a6235",
        "alert": "#ffd0b6",
        "ok": "#d6ffbf",
        "link": "#ffd493",
    },
    "channel-classic": {
        "name": "Channel Classic",
        "bg": "#0b1838",
        "panel": "#10224e",
        "panel2": "#17306a",
        "text": "#f7fbff",
        "muted": "#becce7",
        "accent": "#ffd54d",
        "accent_text": "#11244d",
        "border": "#375b9b",
        "alert": "#ffd6d6",
        "ok": "#d9ffe9",
        "link": "#ffe27c",
    },
}

REFRESH_GUIDE = [
    (30, "Recommended: very live feel, about 86,400 calls/month, only ~4.3% of a 2,000,000-call plan."),
    (60, "Conservative: about 43,200 calls/month, only ~2.2% of a 2,000,000-call plan."),
    (300, "Very light: about 8,640 calls/month."),
]

state_lock = threading.Lock()
last_manual_refresh_epoch = 0.0


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def load_json(path: Path, default: Any) -> Any:
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path: Path, payload: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    tmp.replace(path)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def current_month_key() -> str:
    return datetime.now().strftime("%Y-%m")


def load_config() -> Dict[str, Any]:
    config = DEFAULT_CONFIG.copy()
    user = load_json(CONFIG_PATH, {})
    if isinstance(user, dict):
        config.update(user)
    if config.get("theme") not in THEMES:
        config["theme"] = DEFAULT_CONFIG["theme"]
    return config




def build_weather_query(config: Dict[str, Any]) -> str:
    raw_query = str(config.get("location_query", "")).strip()
    if raw_query:
        return raw_query
    raw_zip = str(config.get("zip_code", "")).strip()
    if raw_zip and raw_zip.replace("-", "").isdigit() and "," not in raw_zip:
        return f"{raw_zip},US"
    return raw_zip or "75081,US"

def location_time_context(cache: Dict[str, Any]) -> Dict[str, str]:
    payload = cache.get("payload", {}) if isinstance(cache, dict) else {}
    location = payload.get("location", {}) if isinstance(payload, dict) else {}
    tz_id = str(location.get("tz_id", "")).strip()
    browser_tz = ""
    now_text = "Unknown"
    api_snapshot = str(location.get("localtime", "")).strip()
    if tz_id:
        try:
            now_dt = datetime.now(ZoneInfo(tz_id))
            now_text = now_dt.strftime("%Y-%m-%d %H:%M:%S")
            browser_tz = tz_id
        except Exception:
            browser_tz = ""
    return {"tz_id": browser_tz, "now_text": now_text, "api_snapshot": api_snapshot}


def patch_sketch_settings(config: Dict[str, Any]) -> None:
    try:
        if not SKETCH_PATH.exists():
            return
        src = SKETCH_PATH.read_text(encoding="utf-8")
        brightness = max(0, min(255, int(config.get("led_matrix_brightness", 180))))
        scroll_ms = max(20, min(500, int(config.get("led_matrix_scroll_ms", 55))))
        src = re.sub(r"const int kScrollMs = \d+;", f"const int kScrollMs = {scroll_ms};", src)
        src = re.sub(r"const int kBrightness = \d+;", f"const int kBrightness = {brightness};", src)
        SKETCH_PATH.write_text(src, encoding="utf-8")
    except Exception:
        pass


def refresh_usage_totals(usage: Dict[str, Any], config: Dict[str, Any] | None = None) -> Dict[str, Any]:
    month = current_month_key()
    if usage.get("month") != month:
        usage["month"] = month
        usage["api_calls_this_month"] = 0
    if config is not None:
        usage["monthly_call_budget"] = int(config["monthly_call_budget"])
    budget = int(usage.get("monthly_call_budget", 0))
    used = int(usage.get("api_calls_this_month", 0))
    usage["remaining_this_month"] = max(0, budget - used)
    usage["boot_loaded_utc"] = usage.get("boot_loaded_utc") or utc_now_iso()
    return usage


def init_usage(config: Dict[str, Any]) -> Dict[str, Any]:
    usage = load_json(
        USAGE_PATH,
        {
            "month": current_month_key(),
            "api_calls_this_month": 0,
            "api_calls_lifetime": 0,
            "last_fetch_utc": "",
            "last_success_utc": "",
            "last_error": "",
            "last_error_utc": "",
            "history_samples": 0,
            "monthly_call_budget": config["monthly_call_budget"],
            "remaining_this_month": config["monthly_call_budget"],
            "boot_loaded_utc": utc_now_iso(),
        },
    )
    refresh_usage_totals(usage, config)
    save_json(USAGE_PATH, usage)
    return usage


def increment_usage(usage: Dict[str, Any]) -> None:
    refresh_usage_totals(usage)
    usage["api_calls_this_month"] = int(usage.get("api_calls_this_month", 0)) + 1
    usage["api_calls_lifetime"] = int(usage.get("api_calls_lifetime", 0)) + 1
    usage["last_fetch_utc"] = utc_now_iso()
    refresh_usage_totals(usage)
    save_json(USAGE_PATH, usage)


def append_history(snapshot: Dict[str, Any], config: Dict[str, Any], usage: Dict[str, Any]) -> None:
    entry = {
        "saved_utc": utc_now_iso(),
        "temp_f": snapshot.get("current", {}).get("temp_f"),
        "humidity": snapshot.get("current", {}).get("humidity"),
        "wind_mph": snapshot.get("current", {}).get("wind_mph"),
        "condition": snapshot.get("current", {}).get("condition", {}).get("text"),
    }
    lines = []
    if HISTORY_PATH.exists():
        try:
            lines = HISTORY_PATH.read_text(encoding="utf-8").splitlines()
        except Exception:
            lines = []
    lines.append(json.dumps(entry))
    max_entries = int(config.get("max_history_entries", 336))
    if len(lines) > max_entries:
        lines = lines[-max_entries:]
    HISTORY_PATH.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    usage["history_samples"] = len(lines)
    refresh_usage_totals(usage)
    save_json(USAGE_PATH, usage)


def read_history() -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    if not HISTORY_PATH.exists():
        return out
    for line in HISTORY_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


def should_save_history(cache: Dict[str, Any], config: Dict[str, Any]) -> bool:
    last_saved = cache.get("history_saved_utc", "")
    if not last_saved:
        return True
    try:
        last_dt = datetime.fromisoformat(last_saved.replace("Z", "+00:00"))
    except ValueError:
        return True
    return (datetime.now(timezone.utc) - last_dt).total_seconds() >= int(config["history_interval_seconds"])


def fetch_weather(config: Dict[str, Any], usage: Dict[str, Any], force: bool = False) -> Dict[str, Any]:
    cache = load_json(CACHE_PATH, {})
    if not force and cache.get("payload") and cache.get("fetched_epoch"):
        age = time.time() - float(cache["fetched_epoch"])
        if age < int(config["refresh_seconds"]):
            return cache

    q = urllib.parse.quote(build_weather_query(config))
    endpoint = (
        f"https://api.weatherapi.com/v1/forecast.json?key={config['weather_api_key']}"
        f"&q={q}&days={int(config['forecast_days'])}&aqi={'yes' if config['show_air_quality'] else 'no'}"
        f"&alerts={'yes' if config['show_alerts'] else 'no'}"
    )

    request = urllib.request.Request(
        endpoint,
        headers={
            "User-Agent": "UNOQ-Weather-Webapp/1.0",
            "Accept": "application/json",
        },
    )

    increment_usage(usage)
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            raw = response.read().decode("utf-8")
        payload = json.loads(raw)
    except Exception as exc:
        usage["last_error"] = str(exc)
        usage["last_error_utc"] = utc_now_iso()
        refresh_usage_totals(usage)
        save_json(USAGE_PATH, usage)
        raise

    usage["last_success_utc"] = utc_now_iso()
    usage["last_error"] = ""
    refresh_usage_totals(usage)
    save_json(USAGE_PATH, usage)

    cache = {
        "fetched_epoch": time.time(),
        "fetched_utc": utc_now_iso(),
        "payload": payload,
        "history_saved_utc": cache.get("history_saved_utc", ""),
    }

    if should_save_history(cache, config):
        append_history(payload, config, usage)
        cache["history_saved_utc"] = utc_now_iso()

    save_json(CACHE_PATH, cache)
    return cache


def escape(value: Any) -> str:
    return (
        str(value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


def mask_key(value: str) -> str:
    value = str(value or "")
    if len(value) <= 8:
        return "*" * len(value)
    return value[:4] + ("*" * (len(value) - 8)) + value[-4:]


def selected_attr(current: str, value: str) -> str:
    return " selected" if current == value else ""


def theme_css(theme_key: str) -> str:
    t = THEMES.get(theme_key, THEMES[DEFAULT_CONFIG["theme"]])
    return f"""
:root {{
  --bg: {t['bg']};
  --panel: {t['panel']};
  --panel2: {t['panel2']};
  --text: {t['text']};
  --muted: {t['muted']};
  --accent: {t['accent']};
  --accent-text: {t['accent_text']};
  --border: {t['border']};
  --alert: {t['alert']};
  --ok: {t['ok']};
  --link: {t['link']};
}}
body {{ margin:0; background:var(--bg); color:var(--text); font-family:Consolas, Monaco, monospace; }}
a {{ color:var(--link); }}
main {{ max-width: 1200px; margin: 0 auto; padding: 16px; }}
.header {{ display:flex; flex-wrap:wrap; gap:14px; align-items:center; justify-content:space-between; margin-bottom:16px; }}
.brand h1 {{ margin:0; font-size:32px; }}
.brand .sub {{ color:var(--muted); margin-top:6px; }}
.panel {{ background:linear-gradient(180deg, var(--panel), var(--panel2)); border:1px solid var(--border); border-radius:16px; padding:16px; margin-bottom:16px; box-shadow:0 12px 28px rgba(0,0,0,0.22); }}
.grid {{ display:grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap:16px; }}
.metric {{ font-size:34px; font-weight:700; margin:4px 0; }}
.small {{ color:var(--muted); font-size:13px; }}
.button, button {{ display:inline-block; background:var(--accent); color:var(--accent-text); border:none; padding:10px 14px; border-radius:10px; font-weight:700; text-decoration:none; cursor:pointer; }}
.button.secondary {{ background:transparent; color:var(--text); border:1px solid var(--border); }}
.button-row {{ display:flex; flex-wrap:wrap; gap:10px; margin-top:12px; }}
.forecast-grid {{ display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:14px; }}
.forecast-card, .alert-card {{ background:rgba(255,255,255,0.04); border:1px solid var(--border); border-radius:12px; padding:12px; }}
.forecast-card h3, .alert-card h3 {{ margin:0 0 8px 0; }}
.table-wrap {{ overflow:auto; }}
table {{ width:100%; border-collapse:collapse; }}
th, td {{ border-bottom:1px solid var(--border); padding:8px; text-align:left; }}
.ok {{ color:var(--ok); }}
.danger {{ color:var(--alert); }}
.form-row {{ display:grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap:16px; align-items:start; }}
label {{ display:block; margin:8px 0 6px; color:var(--muted); line-height:1.35; }}
input, select {{ width:100%; padding:10px; border-radius:10px; border:1px solid var(--border); background:rgba(0,0,0,0.18); color:var(--text); box-sizing:border-box; }}
select option, select optgroup {{ color:#000000; background:#ffffff; }}
.small {{ display:block; line-height:1.4; }}
.footer {{ color:var(--muted); margin:20px 0 8px; font-size:13px; }}
.badge {{ display:inline-block; padding:6px 10px; border-radius:999px; background:rgba(255,255,255,0.06); border:1px solid var(--border); margin-right:8px; margin-top:8px; }}
"""


def theme_options_html(current: str) -> str:
    items = []
    for key, val in THEMES.items():
        items.append(f"<option value='{escape(key)}'{selected_attr(current, key)}>{escape(val['name'])}</option>")
    return "\n".join(items)


def refresh_recommendation(refresh_seconds: int, budget: int) -> str:
    per_month = int((30 * 24 * 60 * 60) / max(1, refresh_seconds))
    pct = (per_month / budget * 100.0) if budget > 0 else 0.0
    if refresh_seconds <= 30:
        level = "Very live"
    elif refresh_seconds <= 60:
        level = "Live and conservative"
    elif refresh_seconds <= 300:
        level = "Light"
    else:
        level = "Very light"
    return f"{level}: about {per_month:,} calls/month, roughly {pct:.1f}% of your {budget:,}-call plan."


def brightness_options_html(current: int) -> str:
    options = [
        (0, "Off"),
        (32, "Very dim"),
        (96, "Dim"),
        (180, "Bright"),
        (255, "Maximum"),
    ]
    items = []
    for value, label in options:
        selected = " selected" if int(current) == value else ""
        items.append(f"<option value='{value}'{selected}>{label}</option>")
    return "\n".join(items)


def settings_page(config: Dict[str, Any], message: str = "") -> str:
    theme = str(config.get("theme", DEFAULT_CONFIG["theme"]))
    budget = int(config.get("monthly_call_budget", 2000000))
    refresh_seconds = int(config.get("refresh_seconds", 30))
    led_brightness = int(config.get("led_matrix_brightness", 180))
    led_scroll_ms = int(config.get("led_matrix_scroll_ms", 55))
    msg_html = f"<div class='panel'><strong>{escape(message)}</strong></div>" if message else ""
    guide_rows = "".join(f"<li>{escape(text)}</li>" for _, text in REFRESH_GUIDE)
    return f"""<!doctype html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>UNO Q Weather Settings</title>
<style>
{theme_css(theme)}
.range-wrap {{ display:flex; gap:12px; align-items:center; }}
.range-wrap input[type=range] {{ flex:1; }}
.range-value {{ min-width:72px; text-align:right; color:var(--text); font-weight:700; }}
</style>
</head>
<body>
<main>
  <div class='panel'>
    <h1>UNO Q Weather Settings</h1>
    <p>Set or change the WeatherAPI key here instead of editing code.</p>
    <p><a class='button' href='https://www.weatherapi.com/' target='_blank' rel='noopener noreferrer'>Get a key from weatherapi.com</a></p>
    <p class='small'>Current stored key: {escape(mask_key(config.get('weather_api_key', '')))}</p>
    <p class='small'>Recommended refresh for your paid plan: 30 seconds.</p>
    <p class='small'>{escape(refresh_recommendation(refresh_seconds, budget))}</p>
  </div>
  {msg_html}
  <div class='panel'>
    <form method='post' action='/settings'>
      <div class='form-row'>
        <div>
          <label for='weather_api_key'>WeatherAPI key</label>
          <input id='weather_api_key' name='weather_api_key' type='text' value='' placeholder='Paste your WeatherAPI key here'>
        </div>
        <div>
          <label for='zip_code'>ZIP code</label>
          <input id='zip_code' name='zip_code' type='text' value='{escape(config.get('zip_code', '75081'))}' placeholder='75081'>
          <div class='small'>US ZIP codes are sent as ZIP,US automatically.</div>
        </div>
      </div>

      <div class='form-row' style='margin-top:8px;'>
        <div style='grid-column: 1 / -1;'>
          <label for='location_query'>Optional exact location query</label>
          <input id='location_query' name='location_query' type='text' value='{escape(config.get('location_query', ''))}' placeholder='75081,US or Richardson,Texas or 32.9483,-96.7299'>
          <div class='small'>Leave blank to use the ZIP code field above.</div>
        </div>
      </div>

      <div class='form-row' style='margin-top:8px;'>
        <div>
          <label for='refresh_seconds'>Refresh seconds</label>
          <input id='refresh_seconds' name='refresh_seconds' type='number' min='15' step='1' value='{escape(refresh_seconds)}'>
        </div>
        <div>
          <label for='theme'>Theme</label>
          <select id='theme' name='theme'>
            {theme_options_html(theme)}
          </select>
        </div>
      </div>

      <div class='form-row' style='margin-top:8px;'>
        <div>
          <label for='led_matrix_brightness'>LED matrix scroll brightness</label>
          <div class='range-wrap'>
            <input id='led_matrix_brightness' name='led_matrix_brightness' type='range' min='0' max='255' step='1' value='{escape(led_brightness)}' oninput='document.getElementById("ledBrightnessValue").textContent=this.value'>
            <div class='range-value' id='ledBrightnessValue'>{escape(led_brightness)}</div>
          </div>
          <div class='small'>0 is off, 255 is maximum. Takes effect after you restart the App Lab app so the sketch can recompile.</div>
        </div>
        <div>
          <label for='led_matrix_scroll_ms'>LED matrix scroll speed (ms per step)</label>
          <div class='range-wrap'>
            <input id='led_matrix_scroll_ms' name='led_matrix_scroll_ms' type='range' min='20' max='200' step='1' value='{escape(led_scroll_ms)}' oninput='document.getElementById("ledSpeedValue").textContent=this.value + " ms"'>
            <div class='range-value' id='ledSpeedValue'>{escape(led_scroll_ms)} ms</div>
          </div>
          <div class='small'>Lower is faster. Takes effect after you restart the App Lab app so the sketch can recompile.</div>
        </div>
      </div>

      <div class='button-row'>
        <button type='submit'>Save settings</button>
        <a class='button secondary' href='/'>Back to dashboard</a>
      </div>
    </form>
  </div>
  <div class='panel'>
    <h2>Refresh guide</h2>
    <ul>
      {guide_rows}
    </ul>
    <p class='small'>This app caches weather locally, but the dashboard will also pull a fresh update whenever the cache is older than the selected refresh time.</p>
  </div>
  <div class='panel'>
    <h2>Share notes</h2>
    <ul>
      <li>No Wi-Fi credentials are stored in this app.</li>
      <li>The UNO Q uses whatever network it is already connected to.</li>
      <li>The dashboard is available at <code>http://&lt;uno-q-ip&gt;:8080</code>.</li>
      <li>For the most exact city match, you can enter an optional exact query like <code>75081,US</code>, <code>Richardson,Texas</code>, or latitude/longitude.</li>
    </ul>
  </div>
</main>
</body>
</html>
"""


def build_dashboard(cache: Dict[str, Any], config: Dict[str, Any], usage: Dict[str, Any]) -> str:
    payload = cache.get("payload", {})
    location = payload.get("location", {})
    current = payload.get("current", {})
    forecast_days = payload.get("forecast", {}).get("forecastday", [])
    alerts = payload.get("alerts", {}).get("alert", [])
    history = read_history()
    theme = str(config.get("theme", DEFAULT_CONFIG["theme"]))

    label = config.get("location_label_override") or (
        f"{location.get('name', 'Unknown')}, {location.get('region', '')}".strip(", ")
    )
    temp = current.get("temp_f", "?")
    feels = current.get("feelslike_f", "?")
    humidity = current.get("humidity", "?")
    wind = current.get("wind_mph", "?")
    pressure = current.get("pressure_in", "?")
    uv = current.get("uv", "?")
    precip = current.get("precip_in", "?")
    condition = current.get("condition", {}).get("text", "N/A")
    icon = current.get("condition", {}).get("icon", "")
    time_ctx = location_time_context(cache)
    localtime = time_ctx.get("now_text", "Unknown")
    tz_id = time_ctx.get("tz_id", "")
    api_snapshot = time_ctx.get("api_snapshot", "")
    last_fetch = cache.get("fetched_utc", "Never")
    age_seconds = int(max(0, time.time() - float(cache.get("fetched_epoch", 0.0)))) if cache.get("fetched_epoch") else -1
    age_string = "Never" if age_seconds < 0 else f"{age_seconds} sec"
    aqi = current.get("air_quality", {})
    refresh_usage_totals(usage)
    budget = int(usage.get("monthly_call_budget", 0))
    used = int(usage.get("api_calls_this_month", 0))
    remaining = int(usage.get("remaining_this_month", max(0, budget - used)))

    history_rows = []
    for item in history[-24:]:
        history_rows.append(
            f"<tr><td>{escape(item.get('saved_utc',''))}</td><td>{escape(item.get('temp_f',''))}</td>"
            f"<td>{escape(item.get('humidity',''))}</td><td>{escape(item.get('wind_mph',''))}</td>"
            f"<td>{escape(item.get('condition',''))}</td></tr>"
        )

    forecast_cards = []
    for day in forecast_days:
        day_info = day.get("day", {})
        astro = day.get("astro", {})
        forecast_cards.append(
            "<div class='forecast-card'>"
            f"<h3>{escape(day.get('date',''))}</h3>"
            f"<div class='small'>Condition: {escape(day_info.get('condition',{}).get('text','N/A'))}</div>"
            f"<div>High: {escape(day_info.get('maxtemp_f','?'))} F</div>"
            f"<div>Low: {escape(day_info.get('mintemp_f','?'))} F</div>"
            f"<div>Rain chance: {escape(day_info.get('daily_chance_of_rain','?'))}%</div>"
            f"<div>Snow chance: {escape(day_info.get('daily_chance_of_snow','?'))}%</div>"
            f"<div>Sunrise: {escape(astro.get('sunrise','N/A'))}</div>"
            f"<div>Sunset: {escape(astro.get('sunset','N/A'))}</div>"
            "</div>"
        )

    alert_block = "<div class='ok'>No active alerts reported.</div>"
    if alerts:
        pieces = []
        for alert in alerts:
            pieces.append(
                "<div class='alert-card'>"
                f"<h3>{escape(alert.get('headline','Alert'))}</h3>"
                f"<div class='small'>Severity: {escape(alert.get('severity','N/A'))} | Areas: {escape(alert.get('areas','N/A'))}</div>"
                f"<div class='small'>Effective: {escape(alert.get('effective','N/A'))}</div>"
                f"<div class='small'>Expires: {escape(alert.get('expires','N/A'))}</div>"
                f"<p>{escape(alert.get('desc',''))}</p>"
                "</div>"
            )
        alert_block = "\n".join(pieces)

    aqi_block = ""
    if config.get("show_air_quality") and aqi:
        aqi_block = f"""
    <div class='panel'>
      <h2>Air Quality</h2>
      <div class='grid'>
        <div><div class='small'>PM2.5</div><div class='metric'>{escape(round(aqi.get('pm2_5', 0), 2))}</div></div>
        <div><div class='small'>PM10</div><div class='metric'>{escape(round(aqi.get('pm10', 0), 2))}</div></div>
        <div><div class='small'>CO</div><div class='metric'>{escape(round(aqi.get('co', 0), 2))}</div></div>
        <div><div class='small'>NO2</div><div class='metric'>{escape(round(aqi.get('no2', 0), 2))}</div></div>
      </div>
    </div>
"""

    recommendation = refresh_recommendation(int(config.get("refresh_seconds", 30)), budget)

    return f"""<!doctype html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>UNO Q Local Weather</title>
<style>
{theme_css(theme)}
</style>
</head>
<body>
<main>
  <div class='header'>
    <div class='brand'>
      <h1>UNO Q Local Weather Station</h1>
      <div class='sub'>{escape(label)} | Local time now: <span id='liveLocalTime'>{escape(localtime)}</span></div>
      <div class='small'>Requested query: {escape(build_weather_query(config))}</div>
      <div class='small'>Time zone: {escape(tz_id or 'Browser local time fallback')} | API snapshot at fetch: {escape(api_snapshot or 'N/A')}</div>
      <div class='small'>Theme: {escape(THEMES[theme]['name'])}</div>
      <div class='small'>Page auto-refresh: every {escape(config.get('refresh_seconds', 30))} seconds</div>
    </div>
    <div>
      <span class='badge'>This month: {used:,} / {budget:,}</span>
      <span class='badge'>Remaining: {remaining:,}</span><span class='badge'>Month: {escape(usage.get('month',''))}</span>
      <span class='badge'>Cache age: {escape(age_string)}</span>
    </div>
  </div>

  <div class='panel'>
    <div class='form-row'>
      <div>
        <div class='small'>Current condition</div>
        <div class='metric'>{escape(temp)} F</div>
        <div>Feels like {escape(feels)} F</div>
        <div>{escape(condition)}</div>
        {f"<div style='margin-top:10px;'><img alt='weather icon' src='https:{escape(icon)}'></div>" if icon else ''}
      </div>
      <div>
        <div class='small'>Details</div>
        <div>Humidity: {escape(humidity)}%</div>
        <div>Wind: {escape(wind)} mph</div>
        <div>Pressure: {escape(pressure)} in</div>
        <div>UV index: {escape(uv)}</div>
        <div>Precipitation: {escape(precip)} in</div>
      </div>
      <div>
        <div class='small'>App status</div>
        <div>Last pulled UTC: {escape(last_fetch)}</div>
        <div>Last success UTC: {escape(usage.get('last_success_utc') or 'Never')}</div><div>Usage loaded from eMMC: {escape(usage.get('boot_loaded_utc') or 'Unknown')}</div>
        <div class='{'danger' if usage.get('last_error') else 'ok'}'>Last error: {escape(usage.get('last_error') or 'None')}</div>
        <div class='small' style='margin-top:8px;'>{escape(recommendation)}</div>
      </div>
    </div>
    <div class='button-row'>
      <a class='button' href='/refresh'>Refresh now</a>
      <a class='button secondary' href='/api/weather'>JSON</a>
      <a class='button secondary' href='/api/status'>Status</a>
      <a class='button secondary' href='/settings'>Settings</a>
    </div>
  </div>
  {aqi_block}

  <div class='panel'>
    <h2>Forecast</h2>
    <div class='forecast-grid'>
      {''.join(forecast_cards) if forecast_cards else '<div class="small">No forecast data yet.</div>'}
    </div>
  </div>

  <div class='panel'>
    <h2>Alerts</h2>
    {alert_block}
  </div>

  <div class='panel'>
    <h2>Recent Weather History</h2>
    <div class='table-wrap'>
      <table>
        <thead>
          <tr><th>Saved UTC</th><th>Temp F</th><th>Humidity</th><th>Wind mph</th><th>Condition</th></tr>
        </thead>
        <tbody>
          {''.join(history_rows) if history_rows else '<tr><td colspan="5">No history samples yet.</td></tr>'}
        </tbody>
      </table>
    </div>
  </div>

  <div class='footer'>Served by UNO Q Python app | Cached API data keeps page loads fast.</div>
</main>
<script>
const refreshSeconds = {escape(config.get('refresh_seconds', 30))};
const locationTz = {json.dumps(tz_id)};
function updateLiveClock() {{
  const node = document.getElementById('liveLocalTime');
  if (!node) return;
  try {{
    const opts = {{ year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', second:'2-digit', hour12:false }};
    if (locationTz) opts.timeZone = locationTz;
    node.textContent = new Intl.DateTimeFormat('sv-SE', opts).format(new Date()).replace('T',' ');
  }} catch (e) {{
    node.textContent = new Date().toLocaleString();
  }}
}}
updateLiveClock();
setInterval(updateLiveClock, 1000);
setTimeout(() => {{
  const u = new URL(window.location.href);
  u.searchParams.set('_ts', Date.now().toString());
  window.location.replace(u.toString());
}}, Math.max(15, Number(refreshSeconds) || 15) * 1000);
</script>
</body>
</html>
"""


class WeatherHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        global last_manual_refresh_epoch
        config = load_config()
        usage = init_usage(config)
        parsed = urllib.parse.urlparse(self.path)
        route = parsed.path or "/"

        if route in ("/", "/index.html"):
            key = str(config.get("weather_api_key", "")).strip()
            if not key or key == "REPLACE_WITH_YOUR_NEW_KEY":
                self._send_html(200, settings_page(config, "Set your WeatherAPI key to start the dashboard."))
                return
            cache = load_json(CACHE_PATH, {})
            cache_age = (time.time() - float(cache.get('fetched_epoch', 0.0))) if cache.get('fetched_epoch') else 10**9
            if (not cache.get("payload")) or cache_age >= int(config.get('refresh_seconds', 30)):
                try:
                    with state_lock:
                        cache = fetch_weather(config, usage, force=True)
                except Exception as exc:
                    if not cache.get('payload'):
                        self._send_html(200, settings_page(config, f"Weather fetch failed: {exc}"))
                        return
            html = build_dashboard(cache, config, usage)
            self._send_html(200, html)
            return

        if route == "/settings":
            self._send_html(200, settings_page(config))
            return

        if route == "/refresh":
            now = time.time()
            if now - last_manual_refresh_epoch < int(config["manual_refresh_cooldown_seconds"]):
                self._redirect("/")
                return
            last_manual_refresh_epoch = now
            try:
                with state_lock:
                    fetch_weather(config, usage, force=True)
            except Exception:
                pass
            self._redirect("/")
            return

        if route == "/api/weather":
            cache = load_json(CACHE_PATH, {})
            self._send_json(200, cache)
            return

        if route == "/api/status":
            cache = load_json(CACHE_PATH, {})
            status = {
                "config": {k: v for k, v in config.items() if k != "weather_api_key"},
                "usage": usage,
                "cache_present": bool(cache.get("payload")),
                "cache_age_seconds": int(max(0, time.time() - float(cache.get("fetched_epoch", 0.0)))) if cache.get("fetched_epoch") else None,
                "themes": [{"key": k, "name": v["name"]} for k, v in THEMES.items()],
            }
            self._send_json(200, status)
            return

        self._send_json(404, {"error": "not found"})

    def do_POST(self) -> None:
        config = load_config()
        parsed = urllib.parse.urlparse(self.path)
        route = parsed.path or "/"
        if route != "/settings":
            self._send_json(404, {"error": "not found"})
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        raw = self.rfile.read(length).decode("utf-8")
        form = urllib.parse.parse_qs(raw, keep_blank_values=True)

        new_key = form.get("weather_api_key", [""])[0].strip()
        new_zip = form.get("zip_code", [str(config.get("zip_code", "75081"))])[0].strip()
        location_query_raw = form.get("location_query", [str(config.get("location_query", ""))])[0].strip()
        refresh_raw = form.get("refresh_seconds", [str(config.get("refresh_seconds", 30))])[0].strip()
        theme_raw = form.get("theme", [str(config.get("theme", DEFAULT_CONFIG["theme"]))])[0].strip()
        brightness_raw = form.get("led_matrix_brightness", [str(config.get("led_matrix_brightness", 180))])[0].strip()
        scroll_ms_raw = form.get("led_matrix_scroll_ms", [str(config.get("led_matrix_scroll_ms", 55))])[0].strip()

        if new_key:
            config["weather_api_key"] = new_key
        config["zip_code"] = new_zip or str(config.get("zip_code", "75081"))
        config["location_query"] = location_query_raw
        try:
            config["refresh_seconds"] = max(15, int(refresh_raw))
        except ValueError:
            pass
        if theme_raw in THEMES:
            config["theme"] = theme_raw
        try:
            config["led_matrix_brightness"] = max(0, min(255, int(brightness_raw)))
        except ValueError:
            pass
        try:
            config["led_matrix_scroll_ms"] = max(20, min(200, int(scroll_ms_raw)))
        except ValueError:
            pass

        save_json(CONFIG_PATH, config)
        patch_sketch_settings(config)

        if CACHE_PATH.exists():
            try:
                CACHE_PATH.unlink()
            except OSError:
                pass

        self._send_html(200, settings_page(config, "Settings saved. Restart the App Lab app if you changed LED brightness or scroll speed so the matrix sketch can recompile with the new values."))

    def log_message(self, fmt: str, *args: Any) -> None:
        print("[%s] %s" % (self.address_string(), fmt % args))

    def _send_html(self, code: int, html: str) -> None:
        body = html.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, code: int, payload: Any) -> None:
        body = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _redirect(self, location: str) -> None:
        self.send_response(302)
        self.send_header("Location", location)
        self.end_headers()


class WeatherFetchThread(threading.Thread):
    daemon = True

    def run(self) -> None:
        while True:
            config = load_config()
            usage = init_usage(config)
            try:
                with state_lock:
                    fetch_weather(config, usage, force=False)
            except Exception as exc:
                print(f"Background fetch failed: {exc}")
            time.sleep(max(10, int(config["refresh_seconds"])))


def main() -> None:
    ensure_dirs()
    config = load_config()
    init_usage(config)
    WeatherFetchThread().start()
    bind_host = str(config.get("bind_host", "0.0.0.0"))
    port = int(config.get("port", 8080))
    server = ThreadingHTTPServer((bind_host, port), WeatherHandler)
    print(f"UNO Q Weather Dashboard listening on http://{bind_host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopping server")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
