/*
  UNO Q built-in LED matrix IP scroller
  Uses low-level matrixBegin/matrixWrite so it works in App Lab without ArduinoGraphics.
  Resolution: 8 rows x 13 cols.
*/
extern "C" void matrixBegin();
extern "C" void matrixWrite(const uint32_t* buf);

constexpr int ROWS = 8;
constexpr int COLS = 13;
constexpr uint16_t ROW_MASK = (1u << COLS) - 1u;
static uint16_t rowsBits[ROWS] = {0};
static uint32_t buf[4] = {0, 0, 0, 0};
static uint32_t blankBuf[4] = {0, 0, 0, 0};

const char* kMessage = "  CONNECT 192.168.0.105:8080  ";
const int kScrollMs = 55;
const int kBrightness = 255; // 0..255, compile-time in this build

struct Glyph { char c; uint8_t w; uint8_t col[5]; };
static const Glyph FONT[] = {
  {' ',3,{0x00,0x00,0x00,0x00,0x00}},
  {'.',1,{0x40,0x00,0x00,0x00,0x00}},
  {':',1,{0x14,0x00,0x00,0x00,0x00}},
  {'0',5,{0x3E,0x51,0x49,0x45,0x3E}},
  {'1',3,{0x42,0x7F,0x40,0x00,0x00}},
  {'2',5,{0x62,0x51,0x49,0x49,0x46}},
  {'3',5,{0x22,0x49,0x49,0x49,0x36}},
  {'4',5,{0x18,0x14,0x12,0x7F,0x10}},
  {'5',5,{0x2F,0x49,0x49,0x49,0x31}},
  {'6',5,{0x3E,0x49,0x49,0x49,0x32}},
  {'7',5,{0x01,0x71,0x09,0x05,0x03}},
  {'8',5,{0x36,0x49,0x49,0x49,0x36}},
  {'9',5,{0x26,0x49,0x49,0x49,0x3E}},
  {'C',5,{0x3E,0x41,0x41,0x41,0x22}},
  {'E',5,{0x7F,0x49,0x49,0x49,0x41}},
  {'N',5,{0x7F,0x04,0x08,0x10,0x7F}},
  {'O',5,{0x3E,0x41,0x41,0x41,0x3E}},
  {'T',5,{0x01,0x01,0x7F,0x01,0x01}},
  {'P',5,{0x7F,0x09,0x09,0x09,0x06}},
};

static const Glyph& glyphFor(char c) {
  for (auto &g : FONT) if (g.c == c) return g;
  return FONT[0];
}

void updateBufFromRows() {
  for (int i = 0; i < 4; ++i) buf[i] = 0;
  int bitPos = 0;
  for (int r = 0; r < ROWS; ++r) {
    for (int c = COLS - 1; c >= 0; --c) {
      uint32_t bit = (rowsBits[r] >> c) & 1u;
      if (bit) buf[bitPos / 32] |= (1u << (bitPos % 32));
      ++bitPos;
    }
  }
}

void pushColumn(uint8_t colBits) {
  for (int r = 0; r < ROWS; ++r) {
    uint16_t bit = (colBits >> r) & 1u;
    rowsBits[r] = uint16_t(((rowsBits[r] << 1) | bit) & ROW_MASK);
  }
}

void showFrameForBrightness(int totalMs) {
  if (kBrightness <= 0) {
    matrixWrite(blankBuf);
    delay(totalMs);
    return;
  }
  if (kBrightness >= 255) {
    matrixWrite(buf);
    delay(totalMs);
    return;
  }
  int onMs = (totalMs * kBrightness) / 255;
  int offMs = totalMs - onMs;
  if (onMs > 0) { matrixWrite(buf); delay(onMs); }
  if (offMs > 0) { matrixWrite(blankBuf); delay(offMs); }
}

void pushBlanks(int n, int speedMs) {
  for (int i = 0; i < n; ++i) {
    pushColumn(0x00);
    updateBufFromRows();
    showFrameForBrightness(speedMs);
  }
}

void scrollText(const char* msg, int speedMs, int spaceCols = 1) {
  pushBlanks(COLS, speedMs);
  for (const char* p = msg; *p; ++p) {
    char ch = *p;
    if (ch >= 'a' && ch <= 'z') ch = char(ch - 32);
    const Glyph& g = glyphFor(ch);
    for (int i = 0; i < g.w; ++i) {
      pushColumn(g.col[i]);
      updateBufFromRows();
      showFrameForBrightness(speedMs);
    }
    for (int s = 0; s < spaceCols; ++s) {
      pushColumn(0x00);
      updateBufFromRows();
      showFrameForBrightness(speedMs);
    }
  }
  pushBlanks(COLS, speedMs);
}

void setup() {
  matrixBegin();
  for (int r = 0; r < ROWS; ++r) rowsBits[r] = 0;
  updateBufFromRows();
  matrixWrite(blankBuf);
}

void loop() {
  scrollText(kMessage, kScrollMs, 1);
}
