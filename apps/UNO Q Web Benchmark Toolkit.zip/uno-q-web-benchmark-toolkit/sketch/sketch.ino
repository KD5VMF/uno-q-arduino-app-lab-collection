\
/*
  Minimal UNO Q MCU sketch for Arduino App Lab projects.

  This app is MPU-side heavy (web UI + benchmarking).
  The MCU sketch simply initializes RouterBridge so you can extend it later
  (GPIO tests, sensors, etc.) without changing the app structure.
*/

#include "Arduino_RouterBridge.h"

void setup() {
  Bridge.begin();
  // No RPC endpoints yet.
}

void loop() {
  // idle
}
