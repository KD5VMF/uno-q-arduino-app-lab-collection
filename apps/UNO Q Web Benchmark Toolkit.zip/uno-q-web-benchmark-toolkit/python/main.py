\
# SPDX-FileCopyrightText: Copyright (C) 2026
# SPDX-License-Identifier: MIT

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from arduino.app_utils import App
from arduino.app_bricks.web_ui import WebUI


APP_ROOT = Path("/app")  # App Lab mounts the project here inside the container
RESULTS_DIR = APP_ROOT / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)


def _read_text(path: str, default: str = "") -> str:
    try:
        return Path(path).read_text(errors="replace")
    except Exception:
        return default


def _run_cmd(argv: List[str], timeout: float = 2.0) -> str:
    """Run a *whitelisted* command and return output (best-effort)."""
    try:
        p = subprocess.run(
            argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            check=False,
            text=True,
        )
        return p.stdout.strip()
    except Exception as e:
        return f"[error] {e}"


def _os_release() -> Dict[str, str]:
    txt = _read_text("/etc/os-release")
    out: Dict[str, str] = {}
    for line in txt.splitlines():
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip().strip('"')
        out[k.strip()] = v
    return out


def _uptime_seconds() -> float:
    # /proc/uptime: "<seconds> <idle_seconds>"
    txt = _read_text("/proc/uptime", "0 0").split()
    try:
        return float(txt[0])
    except Exception:
        return 0.0


def _format_duration(seconds: float) -> str:
    s = int(seconds)
    days, s = divmod(s, 86400)
    hrs, s = divmod(s, 3600)
    mins, s = divmod(s, 60)
    if days:
        return f"{days}d {hrs:02d}h {mins:02d}m {s:02d}s"
    if hrs:
        return f"{hrs}h {mins:02d}m {s:02d}s"
    return f"{mins}m {s:02d}s"


def _meminfo() -> Dict[str, int]:
    # values in kB
    txt = _read_text("/proc/meminfo")
    out: Dict[str, int] = {}
    for line in txt.splitlines():
        if ":" not in line:
            continue
        k, rest = line.split(":", 1)
        parts = rest.strip().split()
        if not parts:
            continue
        try:
            out[k] = int(parts[0])
        except Exception:
            pass
    return out


def _cpu_model() -> str:
    txt = _read_text("/proc/cpuinfo")
    for line in txt.splitlines():
        if line.lower().startswith("model name"):
            return line.split(":", 1)[1].strip()
    # ARM / other formats
    for line in txt.splitlines():
        if line.lower().startswith("hardware"):
            return line.split(":", 1)[1].strip()
    return platform.processor() or "Unknown"


def _thermal_temps_c() -> List[Dict[str, Any]]:
    temps: List[Dict[str, Any]] = []
    base = Path("/sys/class/thermal")
    if not base.exists():
        return temps

    for zone in sorted(base.glob("thermal_zone*")):
        t = _read_text(str(zone / "temp"), "").strip()
        if not t:
            continue
        try:
            milli = int(t)
            c = milli / 1000.0 if milli > 1000 else float(milli)
        except Exception:
            continue
        ttype = _read_text(str(zone / "type"), zone.name).strip() or zone.name
        temps.append({"zone": zone.name, "type": ttype, "c": c})
    return temps


# --- Live stats (CPU%, net, etc.) -------------------------------------------------

_prev_cpu: Optional[Tuple[int, int]] = None  # (total_jiffies, idle_jiffies)


def _cpu_usage_percent() -> float:
    global _prev_cpu
    txt = _read_text("/proc/stat")
    first = txt.splitlines()[0].split()
    if not first or first[0] != "cpu":
        return 0.0
    vals = [int(x) for x in first[1:]]
    idle = vals[3] + (vals[4] if len(vals) > 4 else 0)
    total = sum(vals)
    if _prev_cpu is None:
        _prev_cpu = (total, idle)
        return 0.0
    prev_total, prev_idle = _prev_cpu
    dt = total - prev_total
    di = idle - prev_idle
    _prev_cpu = (total, idle)
    if dt <= 0:
        return 0.0
    return max(0.0, min(100.0, (dt - di) * 100.0 / dt))


def _net_bytes() -> Dict[str, Dict[str, int]]:
    # /proc/net/dev: iface: rx ... tx ...
    txt = _read_text("/proc/net/dev")
    out: Dict[str, Dict[str, int]] = {}
    for line in txt.splitlines()[2:]:
        if ":" not in line:
            continue
        iface, rest = line.split(":", 1)
        iface = iface.strip()
        cols = rest.split()
        if len(cols) < 16:
            continue
        try:
            rx = int(cols[0])
            tx = int(cols[8])
        except Exception:
            continue
        out[iface] = {"rx": rx, "tx": tx}
    return out


# --- Benchmarks -------------------------------------------------------------------

@dataclass
class BenchConfig:
    cpu_seconds: float = 2.5
    mem_mb: int = 256
    disk_mb: int = 256
    disk_dir: str = "results"  # relative to /app
    block_kb: int = 1024        # disk IO block size

@dataclass
class BenchResult:
    name: str
    score: float
    unit: str
    detail: Dict[str, Any]

@dataclass
class BenchStatus:
    state: str = "idle"  # idle|running|done|error
    progress: float = 0.0
    current: str = ""
    started_at: str = ""
    ended_at: str = ""
    error: str = ""
    results: List[BenchResult] = None

    def to_jsonable(self) -> Dict[str, Any]:
        d = asdict(self)
        d["results"] = [asdict(r) for r in (self.results or [])]
        return d


_status = BenchStatus(results=[])
_lock = threading.Lock()
_worker: Optional[threading.Thread] = None


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _cpu_int_ops_per_sec(duration: float) -> BenchResult:
    # xorshift64* style integer work
    x = 0x123456789ABCDEF0
    ops = 0
    t0 = time.perf_counter()
    while True:
        # A few cheap integer ops per iteration
        x ^= (x >> 12) & 0xFFFFFFFFFFFFFFFF
        x ^= (x << 25) & 0xFFFFFFFFFFFFFFFF
        x ^= (x >> 27) & 0xFFFFFFFFFFFFFFFF
        x = (x * 0x2545F4914F6CDD1D) & 0xFFFFFFFFFFFFFFFF
        ops += 1
        if (time.perf_counter() - t0) >= duration:
            break
    dt = time.perf_counter() - t0
    score = ops / dt
    return BenchResult(
        name="CPU Integer (xorshift64*)",
        score=score,
        unit="ops/s",
        detail={"ops": ops, "seconds": dt},
    )


def _cpu_float_mflops(duration: float) -> BenchResult:
    # pure-python float mul-add loop
    a = 1.000001
    b = 1.0000003
    c = 0.9999997
    iters = 0
    t0 = time.perf_counter()
    x = 1.0
    while True:
        # 4 FLOPs-ish per loop (mul/add)
        x = (x * a + b) * c + a
        iters += 1
        if (time.perf_counter() - t0) >= duration:
            break
    dt = time.perf_counter() - t0
    flops = iters * 4
    mflops = (flops / dt) / 1e6
    return BenchResult(
        name="CPU Float (mul-add loop)",
        score=mflops,
        unit="MFLOP/s",
        detail={"iterations": iters, "seconds": dt, "final": x},
    )


def _mem_copy_gbps(mb: int) -> BenchResult:
    size = int(mb) * 1024 * 1024
    src = bytearray(os.urandom(min(size, 4 * 1024 * 1024)))
    # build full size by repetition without another big random call
    if len(src) < size:
        reps = (size + len(src) - 1) // len(src)
        src = (src * reps)[:size]
    dst = bytearray(size)

    mv_src = memoryview(src)
    mv_dst = memoryview(dst)

    t0 = time.perf_counter()
    mv_dst[:] = mv_src
    dt = time.perf_counter() - t0
    gbps = (size / dt) / (1024**3)
    return BenchResult(
        name=f"Memory Copy ({mb} MiB)",
        score=gbps,
        unit="GiB/s",
        detail={"bytes": size, "seconds": dt},
    )


def _disk_write_read_mb_s(mb: int, block_kb: int, rel_dir: str) -> List[BenchResult]:
    target_dir = (APP_ROOT / rel_dir).resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    test_path = target_dir / "bench_tmp.bin"
    size = int(mb) * 1024 * 1024
    block = int(block_kb) * 1024
    data = os.urandom(min(block, 4 * 1024 * 1024))
    if len(data) < block:
        data = (data * ((block + len(data) - 1) // len(data)))[:block]

    # Write
    t0 = time.perf_counter()
    written = 0
    with open(test_path, "wb", buffering=0) as f:
        while written < size:
            chunk = data[: min(block, size - written)]
            f.write(chunk)
            written += len(chunk)
        f.flush()
        os.fsync(f.fileno())
    dt_w = time.perf_counter() - t0
    w_mbs = (written / dt_w) / (1024**2)

    # Read
    t0 = time.perf_counter()
    read = 0
    with open(test_path, "rb", buffering=0) as f:
        while True:
            chunk = f.read(block)
            if not chunk:
                break
            read += len(chunk)
    dt_r = time.perf_counter() - t0
    r_mbs = (read / dt_r) / (1024**2)

    # Cleanup
    try:
        test_path.unlink()
    except Exception:
        pass

    return [
        BenchResult(
            name=f"Disk Write ({mb} MiB)",
            score=w_mbs,
            unit="MiB/s",
            detail={"bytes": written, "seconds": dt_w, "dir": str(target_dir)},
        ),
        BenchResult(
            name=f"Disk Read ({mb} MiB)",
            score=r_mbs,
            unit="MiB/s",
            detail={"bytes": read, "seconds": dt_r, "dir": str(target_dir)},
        ),
    ]


def _run_benchmarks(cfg: BenchConfig) -> None:
    global _status
    try:
        with _lock:
            _status.state = "running"
            _status.progress = 0.0
            _status.current = "starting"
            _status.started_at = _now_iso()
            _status.ended_at = ""
            _status.error = ""
            _status.results = []

        steps = [
            ("cpu_int", 0.20),
            ("cpu_float", 0.20),
            ("mem", 0.25),
            ("disk", 0.35),
        ]
        prog = 0.0

        # CPU int
        with _lock:
            _status.current = "CPU integer"
        r = _cpu_int_ops_per_sec(cfg.cpu_seconds)
        with _lock:
            _status.results.append(r)
            prog += steps[0][1]
            _status.progress = prog

        # CPU float
        with _lock:
            _status.current = "CPU float"
        r = _cpu_float_mflops(cfg.cpu_seconds)
        with _lock:
            _status.results.append(r)
            prog += steps[1][1]
            _status.progress = prog

        # Memory
        with _lock:
            _status.current = "Memory copy"
        r = _mem_copy_gbps(cfg.mem_mb)
        with _lock:
            _status.results.append(r)
            prog += steps[2][1]
            _status.progress = prog

        # Disk
        with _lock:
            _status.current = "Disk write/read"
        rs = _disk_write_read_mb_s(cfg.disk_mb, cfg.block_kb, cfg.disk_dir)
        with _lock:
            _status.results.extend(rs)
            prog += steps[3][1]
            _status.progress = min(1.0, prog)

        with _lock:
            _status.state = "done"
            _status.current = ""
            _status.ended_at = _now_iso()
            _status.progress = 1.0

    except Exception as e:
        with _lock:
            _status.state = "error"
            _status.error = str(e)
            _status.ended_at = _now_iso()
            _status.current = ""


def _start_bench(cfg: BenchConfig) -> Dict[str, Any]:
    global _worker
    with _lock:
        if _status.state == "running":
            return {"ok": False, "error": "Benchmark already running."}
        # spawn worker
        _worker = threading.Thread(target=_run_benchmarks, args=(cfg,), daemon=True)
        _worker.start()
        return {"ok": True}


def _save_latest_results() -> Dict[str, Any]:
    with _lock:
        if _status.state not in ("done", "error"):
            return {"ok": False, "error": "No completed run to save yet."}
        payload = _status.to_jsonable()

    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    out_path = RESULTS_DIR / f"bench_{ts}.json"
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return {"ok": True, "file": str(out_path.relative_to(APP_ROOT))}


# --- REST API ---------------------------------------------------------------------

ui = WebUI(api_path_prefix="/api")  # UI at /, API at /api/...

@ui.app.get("/api/ping")
def api_ping() -> Dict[str, Any]:
    return {"ok": True, "time": _now_iso()}

@ui.app.get("/api/system")
def api_system() -> Dict[str, Any]:
    osr = _os_release()
    mem = _meminfo()

    total_kb = mem.get("MemTotal", 0)
    avail_kb = mem.get("MemAvailable", mem.get("MemFree", 0))
    used_kb = max(0, total_kb - avail_kb)

    du = shutil.disk_usage("/")
    temps = _thermal_temps_c()

    return {
        "generated_at": _now_iso(),
        "hostname": platform.node(),
        "os": {
            "pretty": osr.get("PRETTY_NAME", ""),
            "name": osr.get("NAME", ""),
            "version": osr.get("VERSION", ""),
            "kernel": platform.release(),
            "arch": platform.machine(),
        },
        "uptime": {
            "seconds": _uptime_seconds(),
            "pretty": _format_duration(_uptime_seconds()),
        },
        "cpu": {
            "model": _cpu_model(),
            "cores_logical": os.cpu_count() or 0,
        },
        "memory": {
            "total_bytes": total_kb * 1024,
            "used_bytes": used_kb * 1024,
            "available_bytes": avail_kb * 1024,
        },
        "storage": {
            "root_total_bytes": du.total,
            "root_used_bytes": du.used,
            "root_free_bytes": du.free,
        },
        "temps": temps,
        "network": {
            "ifaces": list(_net_bytes().keys()),
        },
        "raw": {
            "uname": _run_cmd(["uname", "-a"]),
            "lscpu": _run_cmd(["sh", "-lc", "command -v lscpu >/dev/null && lscpu || echo 'lscpu not available'"]),
            "free": _run_cmd(["sh", "-lc", "command -v free >/dev/null && free -h || echo 'free not available'"]),
            "df": _run_cmd(["sh", "-lc", "df -hT | head -n 50"]),
            "ip": _run_cmd(["sh", "-lc", "ip -brief addr 2>/dev/null || ifconfig 2>/dev/null || echo 'ip/ifconfig not available'"]),
        },
    }

@ui.app.get("/api/live")
def api_live() -> Dict[str, Any]:
    mem = _meminfo()
    total_kb = mem.get("MemTotal", 0)
    avail_kb = mem.get("MemAvailable", mem.get("MemFree", 0))
    used_kb = max(0, total_kb - avail_kb)
    du = shutil.disk_usage("/")
    temps = _thermal_temps_c()
    return {
        "time": _now_iso(),
        "cpu_percent": round(_cpu_usage_percent(), 2),
        "mem": {
            "total_bytes": total_kb * 1024,
            "used_bytes": used_kb * 1024,
            "available_bytes": avail_kb * 1024,
        },
        "disk": {
            "root_total_bytes": du.total,
            "root_used_bytes": du.used,
            "root_free_bytes": du.free,
        },
        "temps": temps,
        "net": _net_bytes(),
    }

@ui.app.get("/api/bench/status")
def api_bench_status() -> Dict[str, Any]:
    with _lock:
        return _status.to_jsonable()

@ui.app.post("/api/bench/start")
def api_bench_start(cfg: Dict[str, Any]) -> Dict[str, Any]:
    # Accept partial config; clamp to sane ranges
    bc = BenchConfig()
    try:
        if "cpu_seconds" in cfg:
            bc.cpu_seconds = float(cfg["cpu_seconds"])
        if "mem_mb" in cfg:
            bc.mem_mb = int(cfg["mem_mb"])
        if "disk_mb" in cfg:
            bc.disk_mb = int(cfg["disk_mb"])
        if "disk_dir" in cfg:
            bc.disk_dir = str(cfg["disk_dir"])
        if "block_kb" in cfg:
            bc.block_kb = int(cfg["block_kb"])
    except Exception:
        return {"ok": False, "error": "Invalid config values."}

    # clamp
    bc.cpu_seconds = max(0.5, min(30.0, bc.cpu_seconds))
    bc.mem_mb = max(16, min(2048, bc.mem_mb))
    bc.disk_mb = max(16, min(4096, bc.disk_mb))
    bc.block_kb = max(4, min(4096, bc.block_kb))

    return _start_bench(bc)

@ui.app.post("/api/bench/save")
def api_bench_save() -> Dict[str, Any]:
    return _save_latest_results()

@ui.app.get("/api/bench/history")
def api_bench_history() -> Dict[str, Any]:
    files = sorted(RESULTS_DIR.glob("bench_*.json"), reverse=True)
    out = []
    for p in files[:50]:
        out.append({
            "file": str(p.relative_to(APP_ROOT)),
            "bytes": p.stat().st_size,
            "mtime": datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc).isoformat(),
        })
    return {"files": out}

@ui.app.get("/api/bench/download/{name}")
def api_bench_download(name: str):
    # name like bench_20260221-204000.json
    safe = "".join(c for c in name if c.isalnum() or c in "._-")
    p = RESULTS_DIR / safe
    if not p.exists():
        return {"ok": False, "error": "Not found"}
    # WebUI uses FileResponse internally; import here to avoid extra dependency in top-level
    from fastapi.responses import FileResponse
    return FileResponse(str(p), filename=safe, media_type="application/json")


print("[UNOQ Toolkit] starting WebUI + API on port 7000 ...")
print("[UNOQ Toolkit] open http://localhost:7000/ on the UNO Q, or http://<UNO_Q_HOSTNAME>:7000/ from your LAN")

App.run()  # blocks until stopped
