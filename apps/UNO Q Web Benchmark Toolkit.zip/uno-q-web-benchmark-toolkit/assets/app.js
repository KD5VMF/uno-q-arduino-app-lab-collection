const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

function fmtBytes(n){
  if (n == null) return "—";
  const u = ["B","KiB","MiB","GiB","TiB"];
  let i = 0;
  let x = Number(n);
  while (x >= 1024 && i < u.length-1){ x/=1024; i++; }
  return `${x.toFixed(i===0?0:2)} ${u[i]}`;
}

function clampPct(x){ return Math.max(0, Math.min(100, x)); }

async function getJSON(url){
  const r = await fetch(url, {cache:"no-store"});
  if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
  return await r.json();
}

function setTab(name){
  $$(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
  $$(".panel").forEach(p => p.classList.toggle("active", p.id === `panel-${name}`));
}

$$(".tab").forEach(btn => btn.addEventListener("click", () => setTab(btn.dataset.tab)));

$("#btnRefresh").addEventListener("click", () => refreshAll());

let liveTimer = null;
let benchTimer = null;

async function refreshSystem(){
  const sys = await getJSON("/api/system");
  $("#host").textContent = sys.hostname || "—";
  $("#os").textContent = sys.os.pretty || sys.os.name || "—";
  $("#kernel").textContent = sys.os.kernel || "—";
  $("#uptime").textContent = sys.uptime.pretty || "—";

  $("#cpuModel").textContent = sys.cpu.model || "—";
  $("#cpuCores").textContent = String(sys.cpu.cores_logical ?? "—");

  // Details panel
  $("#rawDetails").textContent = JSON.stringify(sys, null, 2);

  // net ifaces
  $("#ifaces").textContent = (sys.network.ifaces || []).join(", ") || "—";
}

let lastNet = null;
let lastNetTime = null;

async function refreshLive(){
  const live = await getJSON("/api/live");

  $("#cpuPct").textContent = `${live.cpu_percent.toFixed(2)} %`;

  // temps: show max
  if (live.temps && live.temps.length){
    const maxT = Math.max(...live.temps.map(t => t.c));
    $("#cpuTemp").textContent = `${maxT.toFixed(1)} °C`;
  } else {
    $("#cpuTemp").textContent = "—";
  }

  const memUsed = live.mem.used_bytes;
  const memTotal = live.mem.total_bytes;
  const memPct = memTotal ? (memUsed * 100 / memTotal) : 0;
  $("#memBar").style.width = `${clampPct(memPct)}%`;
  $("#memText").textContent = `${fmtBytes(memUsed)} / ${fmtBytes(memTotal)} (${memPct.toFixed(1)}%)`;

  const dUsed = live.disk.root_used_bytes;
  const dTot = live.disk.root_total_bytes;
  const dPct = dTot ? (dUsed * 100 / dTot) : 0;
  $("#diskBar").style.width = `${clampPct(dPct)}%`;
  $("#diskText").textContent = `${fmtBytes(dUsed)} / ${fmtBytes(dTot)} (${dPct.toFixed(1)}%)`;

  // network totals
  const net = live.net || {};
  let rx = 0, tx = 0;
  Object.values(net).forEach(v => { rx += (v.rx||0); tx += (v.tx||0); });

  // optional: show rate if we have a previous sample
  let rxStr = fmtBytes(rx);
  let txStr = fmtBytes(tx);

  const now = Date.now();
  if (lastNet && lastNetTime){
    const dt = (now - lastNetTime) / 1000.0;
    if (dt > 0.2){
      const drx = rx - lastNet.rx;
      const dtx = tx - lastNet.tx;
      rxStr += `  (+${fmtBytes(drx/dt)}/s)`;
      txStr += `  (+${fmtBytes(dtx/dt)}/s)`;
    }
  }
  lastNet = {rx, tx};
  lastNetTime = now;

  $("#rx").textContent = rxStr;
  $("#tx").textContent = txStr;
}

function benchCfgFromUI(){
  return {
    cpu_seconds: Number($("#cfgCpuSeconds").value),
    mem_mb: Number($("#cfgMemMb").value),
    disk_mb: Number($("#cfgDiskMb").value),
    block_kb: Number($("#cfgBlockKb").value),
    disk_dir: "results",
  };
}

async function benchStart(){
  const cfg = benchCfgFromUI();
  const r = await fetch("/api/bench/start", {
    method:"POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify(cfg)
  });
  const j = await r.json();
  if (!j.ok){
    $("#benchStatus").textContent = `error: ${j.error || "unknown"}`;
    return;
  }
  $("#benchStatus").textContent = "running…";
  $("#btnExport").disabled = true;
  startBenchPolling();
}

function renderResults(status){
  const rows = $("#benchRows");
  rows.innerHTML = "";
  if (!status.results || !status.results.length){
    rows.innerHTML = '<tr><td colspan="3" class="muted">No results yet.</td></tr>';
    return;
  }
  for (const r of status.results){
    const tr = document.createElement("tr");
    const name = document.createElement("td"); name.textContent = r.name;
    const score = document.createElement("td"); score.className="r mono"; score.textContent = Number(r.score).toFixed(3);
    const unit = document.createElement("td"); unit.className="mono"; unit.textContent = r.unit;
    tr.appendChild(name); tr.appendChild(score); tr.appendChild(unit);
    rows.appendChild(tr);
  }
}

async function benchPollOnce(){
  const st = await getJSON("/api/bench/status");
  const pct = clampPct((st.progress || 0) * 100);
  $("#benchProgress").style.width = `${pct}%`;

  const state = st.state || "idle";
  const cur = st.current ? ` • ${st.current}` : "";
  const err = st.error ? ` • ${st.error}` : "";
  $("#benchStatus").textContent = `${state}${cur}${err}`;

  renderResults(st);

  const done = (state === "done" || state === "error");
  if (done){
    stopBenchPolling();
    $("#btnExport").disabled = false;
    $("#quickMsg").textContent = done ? "Benchmark finished. You can save or export the JSON." : "—";
  }
  return st;
}

function startBenchPolling(){
  stopBenchPolling();
  benchTimer = setInterval(() => benchPollOnce().catch(()=>{}), 500);
}

function stopBenchPolling(){
  if (benchTimer){ clearInterval(benchTimer); benchTimer = null; }
}

async function copyBenchJSON(){
  const st = await getJSON("/api/bench/status");
  await navigator.clipboard.writeText(JSON.stringify(st, null, 2));
  $("#benchStatus").textContent = "copied JSON to clipboard";
}

async function saveLatest(){
  const r = await fetch("/api/bench/save", {method:"POST"});
  const j = await r.json();
  if (!j.ok){
    $("#quickMsg").textContent = `Save failed: ${j.error || "unknown"}`;
  } else {
    $("#quickMsg").textContent = `Saved: ${j.file}`;
    await loadHistory();
  }
}

async function loadHistory(){
  const h = await getJSON("/api/bench/history");
  const rows = $("#historyRows");
  rows.innerHTML = "";
  if (!h.files || !h.files.length){
    rows.innerHTML = '<tr><td colspan="4" class="muted">No saved runs yet.</td></tr>';
    return;
  }
  for (const f of h.files){
    const tr = document.createElement("tr");

    const tdFile = document.createElement("td");
    tdFile.className = "mono";
    tdFile.textContent = f.file;

    const tdSize = document.createElement("td");
    tdSize.className = "r mono";
    tdSize.textContent = fmtBytes(f.bytes);

    const tdTime = document.createElement("td");
    tdTime.className = "r mono";
    tdTime.textContent = (f.mtime || "").replace("T"," ").replace("+00:00","");

    const tdDl = document.createElement("td");
    tdDl.className = "r";
    const a = document.createElement("a");
    a.className = "btn ghost";
    a.textContent = "Download";
    const name = f.file.split("/").pop();
    a.href = `/api/bench/download/${encodeURIComponent(name)}`;
    a.target = "_blank";
    a.rel = "noreferrer";
    tdDl.appendChild(a);

    tr.appendChild(tdFile);
    tr.appendChild(tdSize);
    tr.appendChild(tdTime);
    tr.appendChild(tdDl);
    rows.appendChild(tr);
  }
}

async function refreshAll(){
  try{
    await refreshSystem();
    await refreshLive();
    await benchPollOnce();
    await loadHistory();
    $("#quickMsg").textContent = "Ready.";
  }catch(e){
    $("#quickMsg").textContent = `Error: ${e.message}`;
  }
}

$("#btnStart").addEventListener("click", () => benchStart().catch(e => $("#benchStatus").textContent = e.message));
$("#btnStartDefault").addEventListener("click", () => { setTab("bench"); benchStart().catch(()=>{}); });
$("#btnExport").addEventListener("click", () => copyBenchJSON().catch(()=>{}));
$("#btnSaveLatest").addEventListener("click", () => saveLatest().catch(()=>{}));
$("#btnReloadHistory").addEventListener("click", () => loadHistory().catch(()=>{}));

(async function init(){
  await refreshAll();
  liveTimer = setInterval(() => refreshLive().catch(()=>{}), 1000);
})();
