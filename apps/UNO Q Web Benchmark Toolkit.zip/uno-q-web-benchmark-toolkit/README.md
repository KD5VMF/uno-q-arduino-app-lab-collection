# 🧰 UNO Q Web Benchmark Toolkit

This Arduino App Lab project runs a **local web dashboard** on your Arduino UNO Q at **port 7000** using the **WebUI - HTML** Brick (FastAPI/Uvicorn under the hood).

It provides:
- A nice web dashboard (system summary + live stats)
- A small benchmark suite (CPU integer/float, memory copy, disk write/read)
- Export + save benchmark results (JSON)

## Run it (Arduino App Lab)
1. Open the App in Arduino App Lab.
2. Click **Run**.
3. App Lab should open the web UI automatically. If not, open:

- `http://localhost:7000/` (when using the UNO Q desktop)
- `http://<UNO_Q_HOSTNAME>:7000/` (from another device on the LAN)

> Tip: The WebUI brick defaults to port **7000**.

## Run it (CLI on the UNO Q)
SSH into the UNO Q and run:

```bash
arduino-app-cli app start ~/ArduinoApps/UNOQ_Web_Benchmark_Toolkit
arduino-app-cli app logs  ~/ArduinoApps/UNOQ_Web_Benchmark_Toolkit
arduino-app-cli app stop  ~/ArduinoApps/UNOQ_Web_Benchmark_Toolkit
```

## Files
- `app.yaml` — App manifest (exposes port 7000 + enables the WebUI brick)
- `python/main.py` — backend (system info + benchmarks + REST API)
- `assets/` — web UI (HTML/CSS/JS)
- `results/` — saved benchmark runs (JSON)
- `sketch/` — minimal MCU sketch (Bridge init; optional)

## Notes
- Benchmarks are **safe by default** (moderate memory + disk sizes). You can increase sizes in the UI.
- Disk tests write a temporary file under `results/` and delete it afterward.
