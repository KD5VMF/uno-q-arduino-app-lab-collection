const pieceMap = {
  'P':'♙','N':'♘','B':'♗','R':'♖','Q':'♕','K':'♔',
  'p':'♟','n':'♞','b':'♝','r':'♜','q':'♛','k':'♚'
};
const $ = (q) => document.querySelector(q);
function setText(id, t){ const el = document.getElementById(id); if (el) el.textContent = t; }
function clamp(n,a,b){ return Math.max(a, Math.min(b,n)); }

let running = false;
let lastFen = "";
let lastMoveUci = "";

function fenToBoard(fen){
  const part = fen.split(" ")[0];
  const rows = part.split("/");
  const grid = [];
  for (const r of rows){
    const row = [];
    for (const ch of r){
      if (ch >= '1' && ch <= '8'){
        for (let i=0;i<parseInt(ch);i++) row.push(null);
      } else row.push(ch);
    }
    grid.push(row);
  }
  return grid;
}

function coordToIndex(file, rank){
  const files = "abcdefgh";
  return {x: files.indexOf(file), y: 8 - parseInt(rank,10)};
}

function renderBoard(fen, lastMove){
  const grid = fenToBoard(fen);
  const boardEl = $("#board");
  if (!boardEl) return;
  boardEl.innerHTML = "";

  const lm = (lastMove && lastMove.length>=4) ? lastMove : "";
  let a=null,b=null;
  if (lm){
    a = coordToIndex(lm[0], lm[1]);
    b = coordToIndex(lm[2], lm[3]);
  }

  for (let y=0;y<8;y++){
    for (let x=0;x<8;x++){
      const sq = document.createElement("div");
      const light = ((x+y)%2===0);
      sq.className = `square ${light?'light':'dark'}`;
      if (a && a.x===x && a.y===y) sq.classList.add("last");
      if (b && b.x===x && b.y===y) sq.classList.add("last");

      const p = grid[y][x];
      if (p){
        const span = document.createElement("span");
        span.className = "piece";
        span.textContent = pieceMap[p] || p;
        sq.appendChild(span);
      }
      boardEl.appendChild(sq);
    }
  }
}

async function api(path, method="GET", body=null){
  const opt = { method, headers:{} };
  if (body !== null){
    opt.headers["Content-Type"] = "application/json";
    opt.body = JSON.stringify(body);
  }
  const r = await fetch(path, opt);
  if (!r.ok){
    const t = await r.text();
    throw new Error(`HTTP ${r.status}: ${t}`);
  }
  return await r.json();
}

async function refresh(){
  try{
    const s = await api("/api/status");

    setText("pillHost", s.host?.hostname ?? "UNOQ");
    setText("pillGames", `Games: ${s.training?.games ?? 0}`);
    setText("pillModel", `Model: ${s.model?.version ?? "v1"}`);
    setText("pillTime", new Date(s.ts*1000).toLocaleTimeString());

    setText("turn", s.board?.turn ?? "--");
    setText("result", s.board?.result ?? "running");
    setText("eval", (s.board?.eval ?? 0).toFixed(3));
    setText("wstats", `W:${s.training?.wins_white ?? 0}  B:${s.training?.wins_black ?? 0}  D:${s.training?.draws ?? 0}`);
    setText("autosave", s.model?.last_save ?? "--");

    setText("alpha", (s.training?.alpha ?? 0).toFixed(4));
    setText("eps", (s.training?.epsilon ?? 0).toFixed(3));
    setText("depth", `${s.training?.depth ?? 1}`);
    setText("speed", `${s.control?.plies_per_sec ?? 0} plies/s`);

    const fen = s.board?.fen ?? "";
    const last = s.board?.last_move_uci ?? "";
    if ((fen && fen !== lastFen) || (last !== lastMoveUci)){
      lastFen = fen;
      lastMoveUci = last;
      renderBoard(fen, last);
    }
    $("#moves").textContent = s.board?.pgn ?? "";

    // sliders mirror server values
    const spd = $("#spd"); if (spd && document.activeElement !== spd) spd.value = clamp(s.control?.plies_per_sec ?? 8, 1, 60);
    const a = $("#s_alpha"); if (a && document.activeElement !== a) a.value = (s.training?.alpha ?? 0.02);
    const e = $("#s_eps"); if (e && document.activeElement !== e) e.value = (s.training?.epsilon ?? 0.08);
    const d = $("#s_depth"); if (d && document.activeElement !== d) d.value = (s.training?.depth ?? 2);

    running = !!s.control?.running;
    $("#btnRun").textContent = running ? "Stop" : "Start";
    $("#btnRun").className = running ? "bad" : "primary";
  }catch(err){
    console.error(err);
  }
}

async function doStep(n=1){ try{ await api("/api/step","POST",{plies:n}); }catch(e){console.error(e);} }
async function toggleRun(){ try{ await api("/api/run","POST",{running: !running}); }catch(e){console.error(e);} }
async function newGame(){ try{ await api("/api/new_game","POST",{}); }catch(e){console.error(e);} }
async function saveModel(){ try{ await api("/api/save","POST",{}); }catch(e){console.error(e);} }

async function exportModel(){
  try{
    const r = await fetch("/api/export");
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "ai_chess_model.json";
    a.click();
    URL.revokeObjectURL(url);
  }catch(e){ console.error(e); }
}

async function importModelText(text){
  try{ await api("/api/import","POST",{json:text}); }catch(e){ console.error(e); }
}

function bind(){
  $("#btnRun").onclick = toggleRun;
  $("#btnStep").onclick = () => doStep(1);
  $("#btnStep10").onclick = () => doStep(10);
  $("#btnNew").onclick = newGame;
  $("#btnSave").onclick = saveModel;
  $("#btnExport").onclick = exportModel;

  $("#spd").oninput = async (ev) => {
    const v = parseInt(ev.target.value,10);
    $("#spdVal").textContent = `${v} plies/s`;
    try{ await api("/api/settings","POST",{plies_per_sec:v}); }catch(e){}
  };
  $("#s_alpha").oninput = async (ev) => {
    const v = parseFloat(ev.target.value);
    $("#alphaVal").textContent = v.toFixed(4);
    try{ await api("/api/settings","POST",{alpha:v}); }catch(e){}
  };
  $("#s_eps").oninput = async (ev) => {
    const v = parseFloat(ev.target.value);
    $("#epsVal").textContent = v.toFixed(3);
    try{ await api("/api/settings","POST",{epsilon:v}); }catch(e){}
  };
  $("#s_depth").oninput = async (ev) => {
    const v = parseInt(ev.target.value,10);
    $("#depthVal").textContent = `${v}`;
    try{ await api("/api/settings","POST",{depth:v}); }catch(e){}
  };

  $("#file").addEventListener("change", async (ev) => {
    const f = ev.target.files?.[0];
    if (!f) return;
    await importModelText(await f.text());
    ev.target.value = "";
  });

  const drop = $("#drop");
  drop.addEventListener("dragover", (e)=>{ e.preventDefault(); drop.style.opacity="1"; });
  drop.addEventListener("dragleave", ()=>{ drop.style.opacity=".85"; });
  drop.addEventListener("drop", async (e)=>{
    e.preventDefault();
    drop.style.opacity=".85";
    const f = e.dataTransfer.files?.[0];
    if (!f) return;
    await importModelText(await f.text());
  });
}

bind();
refresh();
setInterval(refresh, 700);
