from __future__ import annotations

import json
import socket
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict

from trainer import Learner

ROOT = Path(__file__).resolve().parent / "web"
STATIC = ROOT / "static"
INDEX = ROOT / "index.html"

class AppState:
    def __init__(self):
        self.lock = threading.Lock()
        self.learner = Learner(data_dir=Path(__file__).resolve().parent / "data")

        self.running = False
        self.plies_per_sec = 8

        self._worker = threading.Thread(target=self._loop, daemon=True)
        self._worker.start()

    def _loop(self):
        while True:
            time.sleep(0.05)
            with self.lock:
                if not self.running:
                    continue
                pps = max(1, int(self.plies_per_sec))
            per_tick = max(1, int(round(pps * 0.05)))
            with self.lock:
                self.learner.step(per_tick)

STATE = AppState()

def _read_json(handler: SimpleHTTPRequestHandler) -> Dict[str, Any]:
    try:
        n = int(handler.headers.get("Content-Length", "0"))
        raw = handler.rfile.read(n) if n > 0 else b"{}"
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return {}

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path: str) -> str:
        path = path.split("?",1)[0].split("#",1)[0]
        if path == "/":
            return str(INDEX)
        if path == "/index.html":
            return str(INDEX)
        if path.startswith("/static/"):
            return str(STATIC / path[len("/static/"):])
        return str(ROOT / "__nope__")

    def _send_json(self, obj: Any, code: int = 200):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.startswith("/api/status"):
            with STATE.lock:
                s = STATE.learner.status()
                s["control"] = {"running": STATE.running, "plies_per_sec": STATE.plies_per_sec}
                s["host"] = {"hostname": socket.gethostname()}
            return self._send_json(s)

        if self.path.startswith("/api/export"):
            with STATE.lock:
                text = STATE.learner.export_json()
            data = text.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="ai_chess_model.json"')
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path == "/" or self.path == "/index.html" or self.path.startswith("/static/"):
            return super().do_GET()

        self.send_error(404)

    def do_POST(self):
        if self.path.startswith("/api/step"):
            body = _read_json(self)
            plies = int(body.get("plies", 1))
            with STATE.lock:
                STATE.learner.step(plies)
            return self._send_json({"ok": True})

        if self.path.startswith("/api/run"):
            body = _read_json(self)
            running = bool(body.get("running", False))
            with STATE.lock:
                STATE.running = running
            return self._send_json({"running": running})

        if self.path.startswith("/api/new_game"):
            with STATE.lock:
                STATE.learner.reset_game()
            return self._send_json({"ok": True})

        if self.path.startswith("/api/settings"):
            body = _read_json(self)
            with STATE.lock:
                if "plies_per_sec" in body:
                    STATE.plies_per_sec = max(1, min(60, int(body["plies_per_sec"])))
                if "alpha" in body:
                    STATE.learner.train.alpha = max(0.0, min(0.08, float(body["alpha"])))
                if "epsilon" in body:
                    STATE.learner.train.epsilon = max(0.0, min(0.25, float(body["epsilon"])))
                if "depth" in body:
                    STATE.learner.train.depth = max(1, min(3, int(body["depth"])))
            return self._send_json({"ok": True})

        if self.path.startswith("/api/save"):
            with STATE.lock:
                STATE.learner.save()
            return self._send_json({"ok": True})

        if self.path.startswith("/api/import"):
            body = _read_json(self)
            txt = body.get("json", "")
            if not txt:
                return self._send_json({"ok": False, "error": "no json"}, code=400)
            try:
                with STATE.lock:
                    STATE.learner.import_json(txt)
                return self._send_json({"ok": True})
            except Exception as e:
                return self._send_json({"ok": False, "error": str(e)}, code=400)

        return self._send_json({"ok": False, "error": "unknown endpoint"}, code=404)

def serve_in_background(host: str = "0.0.0.0", port: int = 8080):
    httpd = ThreadingHTTPServer((host, port), Handler)
    def _run():
        print(f"[ai-chess] Serving on http://{host}:{port}")
        httpd.serve_forever()
    t = threading.Thread(target=_run, daemon=True)
    t.start()
