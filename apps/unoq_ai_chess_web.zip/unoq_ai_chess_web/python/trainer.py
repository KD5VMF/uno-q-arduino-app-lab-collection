from __future__ import annotations

import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Any, List

import chess
import chess.pgn

from engine import DEFAULT_WEIGHTS, FEATURE_NAMES, features, evaluate, pick_move, SearchConfig, dot

MODEL_VERSION = "v1-linear"

@dataclass
class TrainingState:
    games: int = 0
    wins_white: int = 0
    wins_black: int = 0
    draws: int = 0
    alpha: float = 0.02
    epsilon: float = 0.08
    depth: int = 2

@dataclass
class Model:
    version: str = MODEL_VERSION
    weights: Dict[str, float] = None
    last_save: str = "--"

    def __post_init__(self):
        if self.weights is None:
            self.weights = dict(DEFAULT_WEIGHTS)

class Learner:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.model_path = self.data_dir / "model.json"

        self.model = Model()
        self.train = TrainingState()

        self.board = chess.Board()
        self.last_move_uci: str = ""

        self.pgn_game = chess.pgn.Game()
        self.pgn_node = self.pgn_game

        self._traj: List[Dict[str, float]] = []
        self._autosave_deadline = time.time() + 120.0

        self.load()

    def reset_game(self):
        self.board = chess.Board()
        self.last_move_uci = ""
        self.pgn_game = chess.pgn.Game()
        self.pgn_node = self.pgn_game
        self._traj = []

    def _result_value(self, result: str) -> float:
        if result == "1-0": return 1.0
        if result == "0-1": return -1.0
        return 0.0

    def _update_from_game(self, result_value: float):
        alpha = float(self.train.alpha)
        if not self._traj:
            return

        n = len(self._traj)
        for i, f in enumerate(self._traj):
            decay = 0.40 + 0.60 * (i / max(1, n-1))
            raw = dot(self.model.weights, f)
            pred = float(__import__("math").tanh(raw / 6.0))
            err = (result_value - pred)
            for k in FEATURE_NAMES:
                self.model.weights[k] = self.model.weights.get(k, 0.0) + alpha * decay * err * f.get(k, 0.0)

    def step(self, plies: int = 1) -> None:
        for _ in range(max(1, int(plies))):
            if self.board.is_game_over(claim_draw=True):
                self._finish_game()
                break

            self._traj.append(features(self.board))

            cfg = SearchConfig(depth=self.train.depth, epsilon=self.train.epsilon)
            mv = pick_move(self.model.weights, self.board, cfg)

            self.board.push(mv)
            self.last_move_uci = mv.uci()
            self.pgn_node = self.pgn_node.add_variation(mv)

            if self.board.is_game_over(claim_draw=True):
                self._finish_game()
                break

            if time.time() >= self._autosave_deadline:
                self.save()

    def _finish_game(self):
        res = self.board.result(claim_draw=True)
        rv = self._result_value(res)

        self.train.games += 1
        if res == "1-0": self.train.wins_white += 1
        elif res == "0-1": self.train.wins_black += 1
        else: self.train.draws += 1

        self._update_from_game(rv)
        self.save()
        self.reset_game()

    def status(self) -> Dict[str, Any]:
        return {
            "ts": time.time(),
            "model": {"version": self.model.version, "last_save": self.model.last_save},
            "training": asdict(self.train),
            "board": {
                "fen": self.board.fen(),
                "turn": "White" if self.board.turn == chess.WHITE else "Black",
                "result": self.board.result(claim_draw=True) if self.board.is_game_over(claim_draw=True) else "running",
                "last_move_uci": self.last_move_uci,
                "eval": float(evaluate(self.model.weights, self.board)),
                "pgn": str(self.pgn_game),
            },
        }

    def save(self) -> None:
        blob = {
            "model_version": self.model.version,
            "weights": self.model.weights,
            "training": asdict(self.train),
            "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        tmp = self.model_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(blob, indent=2), encoding="utf-8")
        tmp.replace(self.model_path)
        self.model.last_save = blob["saved_at"]
        self._autosave_deadline = time.time() + 120.0

    def load(self) -> None:
        if not self.model_path.exists():
            self.save()
            return
        try:
            blob = json.loads(self.model_path.read_text(encoding="utf-8"))
            w = blob.get("weights", {})
            self.model.weights = {k: float(w.get(k, DEFAULT_WEIGHTS.get(k, 0.0))) for k in FEATURE_NAMES}
            tr = blob.get("training", {})
            self.train.games = int(tr.get("games", 0))
            self.train.wins_white = int(tr.get("wins_white", 0))
            self.train.wins_black = int(tr.get("wins_black", 0))
            self.train.draws = int(tr.get("draws", 0))
            self.train.alpha = float(tr.get("alpha", self.train.alpha))
            self.train.epsilon = float(tr.get("epsilon", self.train.epsilon))
            self.train.depth = int(tr.get("depth", self.train.depth))
            self.model.last_save = str(blob.get("saved_at", "--"))
        except Exception:
            self.model = Model()
            self.train = TrainingState()
            self.save()

    def export_json(self) -> str:
        blob = {
            "model_version": self.model.version,
            "weights": self.model.weights,
            "training": asdict(self.train),
            "saved_at": self.model.last_save,
        }
        return json.dumps(blob, indent=2)

    def import_json(self, text: str) -> None:
        blob = json.loads(text)
        w = blob.get("weights", {})
        self.model.weights = {k: float(w.get(k, DEFAULT_WEIGHTS.get(k, 0.0))) for k in FEATURE_NAMES}

        tr = blob.get("training", {})
        self.train.games = int(tr.get("games", self.train.games))
        self.train.wins_white = int(tr.get("wins_white", self.train.wins_white))
        self.train.wins_black = int(tr.get("wins_black", self.train.wins_black))
        self.train.draws = int(tr.get("draws", self.train.draws))
        self.train.alpha = float(tr.get("alpha", self.train.alpha))
        self.train.epsilon = float(tr.get("epsilon", self.train.epsilon))
        self.train.depth = int(tr.get("depth", self.train.depth))

        self.model.last_save = str(blob.get("saved_at", self.model.last_save))
        self.save()
