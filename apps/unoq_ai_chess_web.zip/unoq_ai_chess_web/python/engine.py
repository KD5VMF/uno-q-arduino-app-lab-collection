from __future__ import annotations
import math
import random
from dataclasses import dataclass
from typing import Dict, List

import chess

FEATURE_NAMES = [
    "mat_pawn", "mat_knight", "mat_bishop", "mat_rook", "mat_queen",
    "mobility", "bishop_pair", "passed_pawns", "isolated_pawns", "doubled_pawns",
    "center_control", "king_safety", "tempo"
]

DEFAULT_WEIGHTS = {
    "mat_pawn": 1.00,
    "mat_knight": 3.05,
    "mat_bishop": 3.15,
    "mat_rook": 5.00,
    "mat_queen": 9.50,
    "mobility": 0.06,
    "bishop_pair": 0.20,
    "passed_pawns": 0.18,
    "isolated_pawns": -0.12,
    "doubled_pawns": -0.08,
    "center_control": 0.10,
    "king_safety": 0.12,
    "tempo": 0.04,
}

CENTER_SQUARES = {chess.D4, chess.E4, chess.D5, chess.E5}

def _pawn_files(board: chess.Board, color: bool) -> List[int]:
    return [chess.square_file(sq) for sq in board.pieces(chess.PAWN, color)]

def _doubled_pawns(board: chess.Board, color: bool) -> int:
    files = _pawn_files(board, color)
    d = 0
    for f in range(8):
        c = files.count(f)
        if c >= 2:
            d += (c - 1)
    return d

def _isolated_pawns(board: chess.Board, color: bool) -> int:
    files = _pawn_files(board, color)
    iso = 0
    for f in files:
        if (f-1 not in files) and (f+1 not in files):
            iso += 1
    return iso

def _passed_pawns(board: chess.Board, color: bool) -> int:
    opp = not color
    passed_count = 0
    opp_pawns = board.pieces(chess.PAWN, opp)
    for sq in board.pieces(chess.PAWN, color):
        f = chess.square_file(sq)
        r = chess.square_rank(sq)
        blocked = False
        for osq in opp_pawns:
            of = chess.square_file(osq)
            orank = chess.square_rank(osq)
            if abs(of - f) <= 1:
                if color == chess.WHITE and orank > r:
                    blocked = True; break
                if color == chess.BLACK and orank < r:
                    blocked = True; break
        if not blocked:
            passed_count += 1
    return passed_count

def _bishop_pair(board: chess.Board, color: bool) -> int:
    return 1 if len(board.pieces(chess.BISHOP, color)) >= 2 else 0

def _center_control(board: chess.Board, color: bool) -> int:
    return sum(len(board.attackers(color, sq)) for sq in CENTER_SQUARES)

def _king_safety(board: chess.Board, color: bool) -> int:
    score = 0
    if color == chess.WHITE:
        if board.has_kingside_castling_rights(chess.WHITE): score += 1
        if board.has_queenside_castling_rights(chess.WHITE): score += 1
    else:
        if board.has_kingside_castling_rights(chess.BLACK): score += 1
        if board.has_queenside_castling_rights(chess.BLACK): score += 1
    ksq = board.king(color)
    if ksq is not None:
        file = chess.square_file(ksq)
        rank = chess.square_rank(ksq)
        if file in (3,4): score -= 1
        if color == chess.WHITE and rank > 0: score -= 1
        if color == chess.BLACK and rank < 7: score -= 1
    return score

def features(board: chess.Board) -> Dict[str, float]:
    fw: Dict[str, float] = {}
    for pt, name in [(chess.PAWN,"mat_pawn"), (chess.KNIGHT,"mat_knight"), (chess.BISHOP,"mat_bishop"),
                     (chess.ROOK,"mat_rook"), (chess.QUEEN,"mat_queen")]:
        fw[name] = float(len(board.pieces(pt, chess.WHITE)) - len(board.pieces(pt, chess.BLACK)))

    # mobility difference
    turn = board.turn
    board.turn = chess.WHITE
    mw = board.legal_moves.count()
    board.turn = chess.BLACK
    mb = board.legal_moves.count()
    board.turn = turn
    fw["mobility"] = float(mw - mb) / 10.0

    fw["bishop_pair"] = float(_bishop_pair(board, chess.WHITE) - _bishop_pair(board, chess.BLACK))
    fw["passed_pawns"] = float(_passed_pawns(board, chess.WHITE) - _passed_pawns(board, chess.BLACK))
    fw["isolated_pawns"] = float(_isolated_pawns(board, chess.WHITE) - _isolated_pawns(board, chess.BLACK))
    fw["doubled_pawns"] = float(_doubled_pawns(board, chess.WHITE) - _doubled_pawns(board, chess.BLACK))
    fw["center_control"] = float(_center_control(board, chess.WHITE) - _center_control(board, chess.BLACK)) / 6.0
    fw["king_safety"] = float(_king_safety(board, chess.WHITE) - _king_safety(board, chess.BLACK)) / 2.0
    fw["tempo"] = 1.0 if board.turn == chess.WHITE else -1.0
    return fw

def dot(weights: Dict[str, float], feats: Dict[str, float]) -> float:
    return sum(weights.get(k, 0.0) * feats.get(k, 0.0) for k in FEATURE_NAMES)

def evaluate(weights: Dict[str, float], board: chess.Board) -> float:
    if board.is_checkmate():
        return -1.0 if board.turn == chess.WHITE else 1.0
    if board.is_stalemate() or board.is_insufficient_material() or board.can_claim_threefold_repetition():
        return 0.0
    raw = dot(weights, features(board))
    return math.tanh(raw / 6.0)

@dataclass
class SearchConfig:
    depth: int = 2
    epsilon: float = 0.08

def pick_move(weights: Dict[str, float], board: chess.Board, cfg: SearchConfig) -> chess.Move:
    moves = list(board.legal_moves)
    if not moves:
        raise ValueError("No legal moves")
    if random.random() < cfg.epsilon:
        return random.choice(moves)

    d = max(1, min(3, int(cfg.depth)))

    def score_after(move: chess.Move, depth: int) -> float:
        board.push(move)
        try:
            if depth <= 1 or board.is_game_over():
                return evaluate(weights, board)
            child = list(board.legal_moves)
            if not child:
                return evaluate(weights, board)
            vals = [score_after(m2, depth-1) for m2 in child]
            return max(vals) if board.turn == chess.WHITE else min(vals)
        finally:
            board.pop()

    best = None
    bestv = None
    for mv in moves:
        v = score_after(mv, d)
        if best is None:
            best, bestv = mv, v
        else:
            if board.turn == chess.WHITE and v > bestv:
                best, bestv = mv, v
            elif board.turn == chess.BLACK and v < bestv:
                best, bestv = mv, v

    return best if best is not None else random.choice(moves)
