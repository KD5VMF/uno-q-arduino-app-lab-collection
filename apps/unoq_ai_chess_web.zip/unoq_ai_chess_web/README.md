# UNO Q App — AI vs AI Chess (Web GUI, Learns, Saves/Loads)

This is a **UNO Q App Lab app** that serves a web UI at:

- `http://<UNOQ_IP>:8080`

The game runs **AI vs AI self-play** and **learns over time** by updating a small persistent model
(a set of evaluation weights) after each completed game.

✅ The model is automatically:
- **Loaded on startup**
- **Autosaved** periodically and after games
- Can also be **exported/imported** from the web UI

---

## Install / Run (UNO Q)

```bash
arduino-app-cli app install ./unoq_ai_chess_web.zip
arduino-app-cli app start unoq_ai_chess_web
arduino-app-cli app logs  unoq_ai_chess_web
```

Browse:
- `http://<UNOQ_IP>:8080`

Stop:
```bash
arduino-app-cli app stop unoq_ai_chess_web
```

---

## Notes about learning

This uses a lightweight self-play reinforcement approach:
- the AI evaluates positions with a linear model over hand-crafted chess features
- after each self-play game, it nudges the weights toward the winner (alpha / learning-rate)
- it uses shallow search + exploration (epsilon) so it keeps discovering new lines

It will **not** become Stockfish on UNO Q hardware, but it will improve from its own self-play.

---

## Model file location

Inside the app container:
- `python/data/model.json`

Use the UI Export/Import for backups.
