# UNO Q App — LED Matrix Test Patterns (25+)

This App runs a microcontroller sketch that loops **27 unique animated patterns** on the UNO Q built‑in **8×13 LED matrix**. citeturn0search1turn0search0

It uses **8‑level grayscale** for fading and smooth effects. citeturn3view0

## Install / Run (UNO Q)

```bash
arduino-app-cli app install ./unoq_ledmatrix_patterns_app.zip
arduino-app-cli app start unoq_ledmatrix_patterns
arduino-app-cli app logs  unoq_ledmatrix_patterns
```

Stop:
```bash
arduino-app-cli app stop unoq_ledmatrix_patterns
```

## What you’ll see

Patterns rotate every ~4.2 seconds with fade-in/out. Includes:
- breathe / gradients / diagonal sweeps
- checker pulses & scrolling
- scanning bars, Knight‑Rider sweep
- bouncing dots with trails
- sine waves, double sine
- plasma, rings, spiral, ripple
- starfield, rain, fire, sparkles
- noise and Game of Life
- instrument-style animated bars

## MCU-only sketch (optional)

`extras/mcu_only/UNOQ_LEDMatrix_Patterns.ino`

The sketch uses `Arduino_LED_Matrix` which is included in the UNO Q Zephyr core. citeturn3view1
