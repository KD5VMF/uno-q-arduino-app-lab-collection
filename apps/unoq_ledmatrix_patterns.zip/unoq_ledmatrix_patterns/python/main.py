from arduino.app_utils import App
import time

def loop():
    # Matrix patterns run on the MCU sketch; Linux side just keeps the app alive.
    time.sleep(60)

if __name__ == "__main__":
    App.run(user_loop=loop)
