\
/*
  UNO Q LED Matrix Patterns (8x13, monochrome blue, 8-level grayscale)

  - 25+ unique animated test patterns
  - Uses grayscale (setGrayscaleBits(3) -> 8 brightness levels: 0..7)
  - Loops forever, switching patterns every PATTERN_MS with fade in/out

  Notes:
  - Matrix is 8 rows x 13 columns (104 pixels), driven by the STM32U585 (MCU). citeturn0search1
  - Arduino_LED_Matrix is provided by the Arduino Zephyr core for UNO Q (no need to install). citeturn3view1
  - Library API: matrix.begin(), matrix.setGrayscaleBits(n), matrix.draw(buf), matrix.clear(). citeturn3view0
*/

#include <Arduino.h>
#include <Arduino_LED_Matrix.h>

static Arduino_LED_Matrix matrix;

static const int W = 13;
static const int H = 8;
static const int N = W * H;

static const uint32_t PATTERN_MS = 4200;
static const uint32_t FADE_MS    = 450;
static const uint32_t FRAME_MS   = 33;  // ~30 FPS

static inline int idx(int x, int y) { return y * W + x; }
static inline uint8_t clamp8(int v) { return (v < 0) ? 0 : (v > 7 ? 7 : (uint8_t)v); }

static uint8_t buf[N];     // output frame
static uint8_t work[N];    // scratch/state

// Stateful pattern storage
static uint8_t trail[N];
static uint8_t lifeA[N], lifeB[N];
static uint8_t fireA[N];
static int8_t  starX[12], starY[12];
static uint8_t starSpd[12];

static uint8_t pat = 0;
static uint8_t lastPat = 255;
static uint32_t patStart = 0;
static uint32_t frameNo = 0;

static const uint8_t PATTERN_COUNT = 27;

// -------- math helpers (fast-ish integer) -------------------------------------

static int iabs(int v){ return v < 0 ? -v : v; }

// cheap pseudo-sin: precomputed 0..255 -> -127..127
static const int8_t SIN256[256] = {
  0,3,6,9,12,16,19,22,25,28,31,34,37,40,43,46,48,51,54,57,60,62,65,67,70,72,75,77,79,82,84,86,
  88,90,92,94,96,98,100,102,103,105,107,108,110,111,113,114,115,116,118,119,120,121,122,123,124,124,125,126,126,127,127,127,
  127,127,127,127,126,126,125,124,124,123,122,121,120,119,118,116,115,114,113,111,110,108,107,105,103,102,100,98,96,94,92,90,
  88,86,84,82,79,77,75,72,70,67,65,62,60,57,54,51,48,46,43,40,37,34,31,28,25,22,19,16,12,9,6,3,
  0,-3,-6,-9,-12,-16,-19,-22,-25,-28,-31,-34,-37,-40,-43,-46,-48,-51,-54,-57,-60,-62,-65,-67,-70,-72,-75,-77,-79,-82,-84,-86,
  -88,-90,-92,-94,-96,-98,-100,-102,-103,-105,-107,-108,-110,-111,-113,-114,-115,-116,-118,-119,-120,-121,-122,-123,-124,-124,-125,-126,-126,-127,-127,-127,
  -127,-127,-127,-127,-126,-126,-125,-124,-124,-123,-122,-121,-120,-119,-118,-116,-115,-114,-113,-111,-110,-108,-107,-105,-103,-102,-100,-98,-96,-94,-92,-90,
  -88,-86,-84,-82,-79,-77,-75,-72,-70,-67,-65,-62,-60,-57,-54,-51,-48,-46,-43,-40,-37,-34,-31,-28,-25,-22,-19,-16,-12,-9,-6,-3
};

static uint8_t sin01(uint8_t t){
  // map [-127..127] -> [0..7]
  int v = SIN256[t] + 127; // 0..254
  return (uint8_t)((v * 7) / 254);
}

static uint8_t tri01(uint8_t t){
  // triangle wave 0..7
  uint8_t a = (t & 127);
  uint8_t v = (t & 128) ? (127 - a) : a; // 0..127
  return (uint8_t)((v * 7) / 127);
}

// -------- common utilities -----------------------------------------------------

static void clearAll(uint8_t* a, uint8_t v=0){
  for(int i=0;i<N;i++) a[i]=v;
}

static void fadeArray(uint8_t* a, uint8_t dec){
  for(int i=0;i<N;i++){
    a[i] = (a[i] > dec) ? (a[i] - dec) : 0;
  }
}

static void addPix(uint8_t* a, int x, int y, int v){
  if(x<0||x>=W||y<0||y>=H) return;
  int i = idx(x,y);
  int nv = (int)a[i] + v;
  a[i] = clamp8(nv);
}

static void setPix(uint8_t* a, int x, int y, int v){
  if(x<0||x>=W||y<0||y>=H) return;
  a[idx(x,y)] = clamp8(v);
}

// Bresenham line, brightness v
static void line(uint8_t* a, int x0,int y0,int x1,int y1,int v){
  int dx = iabs(x1-x0), sx = x0<x1 ? 1 : -1;
  int dy = -iabs(y1-y0), sy = y0<y1 ? 1 : -1;
  int err = dx + dy;
  while(true){
    setPix(a,x0,y0,v);
    if(x0==x1 && y0==y1) break;
    int e2 = 2*err;
    if(e2 >= dy){ err += dy; x0 += sx; }
    if(e2 <= dx){ err += dx; y0 += sy; }
  }
}

static void initPattern(uint8_t p){
  clearAll(work,0);
  clearAll(trail,0);
  clearAll(fireA,0);

  // Seed life
  for(int i=0;i<N;i++){
    lifeA[i] = (random(100) < 28) ? 7 : 0;
    lifeB[i] = 0;
  }

  // Seed stars
  for(int i=0;i<12;i++){
    starX[i] = random(W);
    starY[i] = random(H);
    starSpd[i] = 1 + random(2);
  }

  // Pattern-specific: add an initial ripple drop
  if(p==21){
    // ripple uses work as phase map
    for(int i=0;i<N;i++) work[i]=0;
  }
}

// -------- 27 patterns ----------------------------------------------------------
// Each pattern writes buf[] values 0..7.

static void pat0_breathe(uint32_t f){
  uint8_t b = tri01((uint8_t)(f*2));
  for(int i=0;i<N;i++) buf[i]=b;
}

static void pat1_hgrad(uint32_t f){
  for(int y=0;y<H;y++){
    for(int x=0;x<W;x++){
      int v = ((x + (int)(f/2)) % W) * 7 / (W-1);
      buf[idx(x,y)] = (uint8_t)v;
    }
  }
}

static void pat2_vgrad(uint32_t f){
  for(int y=0;y<H;y++){
    int vrow = ((y + (int)(f/3)) % H) * 7 / (H-1);
    for(int x=0;x<W;x++) buf[idx(x,y)] = (uint8_t)vrow;
  }
}

static void pat3_diag(uint32_t f){
  for(int y=0;y<H;y++){
    for(int x=0;x<W;x++){
      int v = (x + y + (int)(f/3)) % (W+H);
      v = (v * 7) / (W+H-2);
      buf[idx(x,y)] = (uint8_t)v;
    }
  }
}

static void pat4_checker_pulse(uint32_t f){
  uint8_t b = tri01((uint8_t)(f*3));
  for(int y=0;y<H;y++){
    for(int x=0;x<W;x++){
      buf[idx(x,y)] = ((x+y)&1) ? b : (7-b);
    }
  }
}

static void pat5_checker_scroll(uint32_t f){
  int ox = (f/3) % 2;
  int oy = (f/5) % 2;
  for(int y=0;y<H;y++){
    for(int x=0;x<W;x++){
      int c = ((x+ox)+(y+oy))&1;
      buf[idx(x,y)] = c?7:0;
    }
  }
}

static void pat6_vbar(uint32_t f){
  int x0 = (f/2) % W;
  for(int y=0;y<H;y++){
    for(int x=0;x<W;x++){
      int d = iabs(x-x0);
      int v = 7 - d*3;
      buf[idx(x,y)] = clamp8(v);
    }
  }
}

static void pat7_hbar(uint32_t f){
  int y0 = (f/3) % H;
  for(int y=0;y<H;y++){
    for(int x=0;x<W;x++){
      int d = iabs(y-y0);
      int v = 7 - d*4;
      buf[idx(x,y)] = clamp8(v);
    }
  }
}

static void pat8_bounce_dot(uint32_t f){
  fadeArray(trail, 1);
  int x = (int)(f/2) % (2*(W-1));
  int y = (int)(f/3) % (2*(H-1));
  if(x >= W) x = 2*(W-1) - x;
  if(y >= H) y = 2*(H-1) - y;
  addPix(trail, x, y, 7);
  for(int i=0;i<N;i++) buf[i]=trail[i];
}

static void pat9_two_dots(uint32_t f){
  fadeArray(trail, 1);
  int x1 = (int)(f/2) % (2*(W-1));
  int y1 = (int)(f/3) % (2*(H-1));
  int x2 = (int)(f/2 + 17) % (2*(W-1));
  int y2 = (int)(f/3 + 29) % (2*(H-1));
  if(x1 >= W) x1 = 2*(W-1) - x1;
  if(y1 >= H) y1 = 2*(H-1) - y1;
  if(x2 >= W) x2 = 2*(W-1) - x2;
  if(y2 >= H) y2 = 2*(H-1) - y2;
  addPix(trail, x1,y1,7);
  addPix(trail, x2,y2,7);
  for(int i=0;i<N;i++) buf[i]=trail[i];
}

static void pat10_sine(uint32_t f){
  clearAll(buf,0);
  for(int x=0;x<W;x++){
    uint8_t t = (uint8_t)(x*18 + f*5);
    int y = (SIN256[t] + 127) * (H-1) / 254;
    setPix(buf, x, y, 7);
    // soft glow
    addPix(buf, x, y-1, 3);
    addPix(buf, x, y+1, 3);
  }
}

static void pat11_double_sine(uint32_t f){
  clearAll(buf,0);
  for(int x=0;x<W;x++){
    uint8_t t1 = (uint8_t)(x*16 + f*4);
    uint8_t t2 = (uint8_t)(x*23 + f*3);
    int y1 = (SIN256[t1] + 127) * (H-1) / 254;
    int y2 = (SIN256[t2] + 127) * (H-1) / 254;
    setPix(buf, x, y1, 7);
    setPix(buf, x, y2, 5);
  }
}

static void pat12_plasma(uint32_t f){
  for(int y=0;y<H;y++){
    for(int x=0;x<W;x++){
      uint8_t a = (uint8_t)(x*19 + f*2);
      uint8_t b = (uint8_t)(y*33 + f*3);
      uint8_t c = (uint8_t)((x+y)*11 + f*4);
      int v = (sin01(a) + sin01(b) + tri01(c));
      v = (v * 7) / 21;
      buf[idx(x,y)] = (uint8_t)v;
    }
  }
}

static void pat13_rings(uint32_t f){
  int cx = (W-1)*10/2;
  int cy = (H-1)*10/2;
  for(int y=0;y<H;y++){
    for(int x=0;x<W;x++){
      int dx = x*10 - cx;
      int dy = y*10 - cy;
      int d  = (int)(sqrt((float)(dx*dx + dy*dy))); // small, ok
      int v = 7 - ((d + (int)(f*2)) % 35) / 5;
      buf[idx(x,y)] = clamp8(v);
    }
  }
}

static void pat14_rotate_line(uint32_t f){
  clearAll(buf,0);
  float ang = (float)(f % 360) * 0.0174533f;
  float cx = (W-1)/2.0f;
  float cy = (H-1)/2.0f;
  float r = (W>H?W:H);
  int x0 = (int)(cx + cosf(ang) * r);
  int y0 = (int)(cy + sinf(ang) * r);
  int x1 = (int)(cx - cosf(ang) * r);
  int y1 = (int)(cy - sinf(ang) * r);
  line(buf, x0,y0,x1,y1,7);
}

static void pat15_starfield(uint32_t f){
  (void)f;
  fadeArray(trail, 2);
  // move stars downward
  for(int i=0;i<12;i++){
    starY[i] += starSpd[i];
    if(starY[i] >= H){
      starY[i] = 0;
      starX[i] = random(W);
      starSpd[i] = 1 + random(2);
    }
    addPix(trail, starX[i], starY[i], 7);
    addPix(trail, starX[i], starY[i]-1, 3);
  }
  for(int i=0;i<N;i++) buf[i]=trail[i];
}

static void pat16_rain(uint32_t f){
  (void)f;
  fadeArray(trail, 1);
  // new drops
  if(random(100) < 35){
    int x = random(W);
    addPix(trail, x, 0, 7);
  }
  // shift down with decay
  for(int y=H-1;y>0;y--){
    for(int x=0;x<W;x++){
      int i = idx(x,y);
      int j = idx(x,y-1);
      trail[i] = clamp8((int)trail[i] + (int)trail[j] - 1);
    }
  }
  // top row slowly fades
  for(int x=0;x<W;x++){
    int i = idx(x,0);
    trail[i] = (trail[i] > 1) ? (trail[i]-1) : 0;
  }
  for(int i=0;i<N;i++) buf[i]=trail[i];
}

static void pat17_fire(uint32_t f){
  (void)f;
  // Fire buffer fireA holds intensity 0..7
  // Seed bottom row
  for(int x=0;x<W;x++){
    int i = idx(x,H-1);
    int r = random(100);
    int v = (r < 55) ? 7 : (r < 75 ? 5 : (r < 90 ? 3 : 0));
    fireA[i] = (uint8_t)v;
  }
  // Propagate upward
  for(int y=0;y<H-1;y++){
    for(int x=0;x<W;x++){
      int below = idx(x, y+1);
      int belowL = idx((x==0?0:x-1), y+1);
      int belowR = idx((x==W-1?W-1:x+1), y+1);
      int v = (int)fireA[below] + (int)fireA[belowL] + (int)fireA[belowR];
      v = v / 3;
      v = v - 1; // cool
      if(v < 0) v = 0;
      fireA[idx(x,y)] = (uint8_t)v;
    }
  }
  for(int i=0;i<N;i++) buf[i]=fireA[i];
}

static void pat18_sparkle(uint32_t f){
  (void)f;
  fadeArray(trail, 1);
  for(int k=0;k<3;k++){
    if(random(100) < 45){
      int x = random(W);
      int y = random(H);
      addPix(trail, x,y,7);
    }
  }
  for(int i=0;i<N;i++) buf[i]=trail[i];
}

static void pat19_noise(uint32_t f){
  (void)f;
  for(int i=0;i<N;i++){
    int r = random(8);
    buf[i] = (uint8_t)r;
  }
}

static int neighbors(const uint8_t* a, int x, int y){
  int n=0;
  for(int dy=-1;dy<=1;dy++){
    for(int dx=-1;dx<=1;dx++){
      if(dx==0 && dy==0) continue;
      int xx=x+dx, yy=y+dy;
      if(xx<0||xx>=W||yy<0||yy>=H) continue;
      if(a[idx(xx,yy)]>0) n++;
    }
  }
  return n;
}

static void pat20_life(uint32_t f){
  // update every ~6 frames
  if((f % 6) == 0){
    for(int y=0;y<H;y++){
      for(int x=0;x<W;x++){
        int i = idx(x,y);
        int n = neighbors(lifeA,x,y);
        bool alive = lifeA[i] > 0;
        bool next = (alive && (n==2 || n==3)) || (!alive && n==3);
        // use grayscale: new cell bright, old cell medium
        lifeB[i] = next ? 7 : 0;
      }
    }
    for(int i=0;i<N;i++) lifeA[i]=lifeB[i];
    // If life dies out, reseed
    int s=0; for(int i=0;i<N;i++) s += lifeA[i]>0;
    if(s < 6){
      for(int i=0;i<N;i++) lifeA[i] = (random(100) < 30) ? 7 : 0;
    }
  }
  for(int i=0;i<N;i++) buf[i]=lifeA[i];
}

static void pat21_ripple(uint32_t f){
  int cx = (W-1);
  int cy = (H-1);
  cx = cx/2; cy = cy/2;
  for(int y=0;y<H;y++){
    for(int x=0;x<W;x++){
      int dx = x-cx;
      int dy = y-cy;
      int d = (int)(sqrt((float)(dx*dx + dy*dy))*10.0f); // scaled
      int t = (d + (int)(f*6)) & 255;
      int v = (SIN256[t] + 127) * 7 / 254;
      // emphasize edges
      v = (v > 4) ? 7 : v;
      buf[idx(x,y)] = (uint8_t)v;
    }
  }
}

static void pat22_cross_pulse(uint32_t f){
  clearAll(buf,0);
  uint8_t b = tri01((uint8_t)(f*4));
  int cx = W/2;
  int cy = H/2;
  for(int x=0;x<W;x++) addPix(buf,x,cy,b);
  for(int y=0;y<H;y++) addPix(buf,cx,y,b);
  // corners glow
  addPix(buf,0,0,b/2);
  addPix(buf,W-1,0,b/2);
  addPix(buf,0,H-1,b/2);
  addPix(buf,W-1,H-1,b/2);
}

static void pat23_knight_rider(uint32_t f){
  clearAll(buf,0);
  int x0 = (f/2) % (2*(W-1));
  if(x0 >= W) x0 = 2*(W-1) - x0;
  for(int y=0;y<H;y++){
    for(int x=0;x<W;x++){
      int d = iabs(x-x0);
      int v = 7 - d*2;
      addPix(buf,x,y, clamp8(v));
    }
  }
}

static void pat24_spiral(uint32_t f){
  int cx = (W-1)*10/2;
  int cy = (H-1)*10/2;
  for(int y=0;y<H;y++){
    for(int x=0;x<W;x++){
      float dx = (x*10 - cx) / 10.0f;
      float dy = (y*10 - cy) / 10.0f;
      float ang = atan2f(dy, dx); // -pi..pi
      float dist = sqrtf(dx*dx + dy*dy);
      float phase = ang*40.0f + dist*18.0f + (float)f*0.9f;
      int t = ((int)phase) & 255;
      buf[idx(x,y)] = sin01((uint8_t)t);
    }
  }
}

static void pat25_lissajous(uint32_t f){
  fadeArray(trail, 1);
  float t = (float)f * 0.08f;
  float ax = (W-1)/2.0f;
  float ay = (H-1)/2.0f;
  int x = (int)(ax + ax * sinf(t*1.3f));
  int y = (int)(ay + ay * sinf(t*2.1f + 1.2f));
  addPix(trail,x,y,7);
  for(int i=0;i<N;i++) buf[i]=trail[i];
}

static void pat26_telemetry_bars(uint32_t f){
  // Looks like a test instrument: three animated bar graphs
  clearAll(buf,0);
  uint8_t a = sin01((uint8_t)(f*3));
  uint8_t b = tri01((uint8_t)(f*2));
  uint8_t c = sin01((uint8_t)(f*5 + 80));
  int ha = (a * H) / 7;
  int hb = (b * H) / 7;
  int hc = (c * H) / 7;
  for(int y=0;y<H;y++){
    for(int x=0;x<4;x++) if(H-1-y < ha) buf[idx(x,y)] = 7;
    for(int x=5;x<8;x++) if(H-1-y < hb) buf[idx(x,y)] = 6;
    for(int x=9;x<13;x++) if(H-1-y < hc) buf[idx(x,y)] = 5;
  }
}

// Dispatcher
static void renderPattern(uint8_t p, uint32_t f){
  switch(p){
    case 0:  pat0_breathe(f); break;
    case 1:  pat1_hgrad(f); break;
    case 2:  pat2_vgrad(f); break;
    case 3:  pat3_diag(f); break;
    case 4:  pat4_checker_pulse(f); break;
    case 5:  pat5_checker_scroll(f); break;
    case 6:  pat6_vbar(f); break;
    case 7:  pat7_hbar(f); break;
    case 8:  pat8_bounce_dot(f); break;
    case 9:  pat9_two_dots(f); break;
    case 10: pat10_sine(f); break;
    case 11: pat11_double_sine(f); break;
    case 12: pat12_plasma(f); break;
    case 13: pat13_rings(f); break;
    case 14: pat14_rotate_line(f); break;
    case 15: pat15_starfield(f); break;
    case 16: pat16_rain(f); break;
    case 17: pat17_fire(f); break;
    case 18: pat18_sparkle(f); break;
    case 19: pat19_noise(f); break;
    case 20: pat20_life(f); break;
    case 21: pat21_ripple(f); break;
    case 22: pat22_cross_pulse(f); break;
    case 23: pat23_knight_rider(f); break;
    case 24: pat24_spiral(f); break;
    case 25: pat25_lissajous(f); break;
    default: pat26_telemetry_bars(f); break;
  }
}

static void applyFade(uint8_t* a, uint8_t fade7){
  // fade7: 0..7
  for(int i=0;i<N;i++){
    a[i] = (uint8_t)((a[i] * fade7) / 7);
  }
}

void setup(){
  Serial.begin(115200);
  delay(200);

  randomSeed((uint32_t)micros());

  matrix.begin();
  matrix.setGrayscaleBits(3); // 8 levels citeturn3view0

  patStart = millis();
  pat = 0;
  initPattern(pat);

  Serial.println("[UNOQ] LED matrix patterns starting.");
}

void loop(){
  uint32_t now = millis();
  uint32_t t = now - patStart;

  // advance pattern
  if(t >= PATTERN_MS){
    patStart = now;
    t = 0;
    pat = (uint8_t)((pat + 1) % PATTERN_COUNT);
  }

  if(pat != lastPat){
    lastPat = pat;
    initPattern(pat);
    Serial.print("[UNOQ] Pattern ");
    Serial.println((int)pat);
  }

  // fade in/out factor 0..7
  uint8_t fade7 = 7;
  if(t < FADE_MS){
    fade7 = (uint8_t)((t * 7) / FADE_MS);
  } else if(t > (PATTERN_MS - FADE_MS)){
    fade7 = (uint8_t)(((PATTERN_MS - t) * 7) / FADE_MS);
  }

  renderPattern(pat, frameNo);
  applyFade(buf, fade7);

  matrix.draw(buf);

  frameNo++;
  delay(FRAME_MS);
}
