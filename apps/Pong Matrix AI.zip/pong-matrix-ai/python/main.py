# SPDX-License-Identifier: MPL-2.0
from __future__ import annotations
import time
from arduino.app_utils import App, Logger

log = Logger("pong-matrix-ai")

_started = False

def loop():
    global _started
    if not _started:
        _started = True
        log.info("Pong Matrix AI started (game runs on MCU).")
    time.sleep(30)

App.run(user_loop=loop)
