# Pong Matrix AI (Arduino UNO Q)

Autoplaying **Pong (AI vs AI)** on the UNO Q **13×8 LED matrix**.

## Install

Copy this app folder to:

`/home/arduino/ArduinoApps/pong_matrix_ai`

Example:

```bash
scp -r pong_matrix_ai arduino@<UNOQ_IP>:/home/arduino/ArduinoApps/
```

Or on the UNO Q:

```bash
mkdir -p ~/ArduinoApps
unzip pong_matrix_ai.zip -d ~/ArduinoApps/
```

## Run

```bash
arduino-app-cli app start ~/ArduinoApps/pong_matrix_ai
```

Logs (Python side is mostly idle; the game runs on the MCU):

```bash
arduino-app-cli app logs ~/ArduinoApps/pong_matrix_ai
```

## Notes

- The game runs entirely on the MCU and keeps going forever.
- AI paddles track the ball with small randomness so it looks “alive”.
- Library note: Arduino App Lab may warn about architectures for ArduinoGraphics; you can ignore the warning if the build completes.
