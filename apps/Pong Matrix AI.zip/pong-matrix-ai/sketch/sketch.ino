// SPDX-License-Identifier: MPL-2.0
/*
  Pong Matrix AI (UNO Q) — AI vs AI Pong on 13×8 LED matrix

  Matrix:
    width  = 13 (x: 0..12)
    height = 8  (y: 0..7)

  Paddles:
    left  at x=0
    right at x=12
    height = 3

  Ball:
    single pixel, velocity vx in {-1,+1}, vy in {-1,0,+1}

  Render:
    matrix.renderBitmap(grid, 8, 13)

  Note:
    Arduino_LED_Matrix has a known dependency on ArduinoGraphics headers in some examples.
    We include ArduinoGraphics before Arduino_LED_Matrix to keep builds happy across cores.
*/

#include <Arduino.h>
// Include BEFORE Arduino_LED_Matrix per upstream guidance
#include "ArduinoGraphics.h"
#include "Arduino_LED_Matrix.h"

Arduino_LED_Matrix matrix;

static constexpr int W = 13;
static constexpr int H = 8;

static constexpr int PADDLE_H = 3;
static constexpr int LEFT_X  = 0;
static constexpr int RIGHT_X = W - 1;

static uint8_t grid[H][W];

// Game state
static int lp_y = 2;  // left paddle top
static int rp_y = 2;  // right paddle top

static int ball_x = W / 2;
static int ball_y = H / 2;

static int vx = 1;
static int vy = 1;

static uint16_t score_l = 0;
static uint16_t score_r = 0;

static uint32_t last_tick_ms = 0;
static constexpr uint32_t FRAME_MS = 50;   // ~20 FPS (looks good on the tiny matrix)

static bool in_point_pause = false;
static uint32_t pause_until_ms = 0;
static int last_scorer = 0; // -1 left, +1 right

static inline int clampi(int v, int lo, int hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

static void clear_grid() {
  memset(grid, 0, sizeof(grid));
}

static void draw_center_net() {
  // dotted net at x=6
  const int x = 6;
  for (int y = 0; y < H; y += 2) {
    grid[y][x] = 1;
  }
}

static void draw_paddles() {
  for (int dy = 0; dy < PADDLE_H; dy++) {
    int yL = lp_y + dy;
    int yR = rp_y + dy;
    if (yL >= 0 && yL < H) grid[yL][LEFT_X] = 1;
    if (yR >= 0 && yR < H) grid[yR][RIGHT_X] = 1;
  }
}

static void draw_ball() {
  if (ball_x >= 0 && ball_x < W && ball_y >= 0 && ball_y < H) {
    grid[ball_y][ball_x] = 1;
  }
}

static void render() {
  matrix.renderBitmap(grid, H, W);
}

static void reset_ball(int serve_dir) {
  ball_x = W / 2;
  ball_y = H / 2;

  // Serve left (-1) or right (+1)
  vx = (serve_dir < 0) ? -1 : 1;

  // Randomize vy a bit, but avoid 0 too often
  int r = random(0, 3); // 0,1,2
  vy = (r == 0) ? -1 : (r == 1 ? 1 : 0);
  // small chance to make it 0
  if (random(0, 10) == 0) vy = 0;
}

static void point_scored(int scorer) {
  // scorer: -1 left, +1 right
  last_scorer = scorer;
  if (scorer < 0) score_l++;
  else score_r++;

  in_point_pause = true;
  pause_until_ms = millis() + 450; // show a quick flash
  reset_ball(-scorer);             // serve toward the player who lost the point
}

static bool paddle_hits_left(int next_x, int next_y) {
  if (next_x != LEFT_X) return false;
  return (next_y >= lp_y && next_y < lp_y + PADDLE_H);
}

static bool paddle_hits_right(int next_x, int next_y) {
  if (next_x != RIGHT_X) return false;
  return (next_y >= rp_y && next_y < rp_y + PADDLE_H);
}

static void adjust_vy_on_hit(int paddle_top, int hit_y) {
  // Paddle center at paddle_top + 1 for PADDLE_H=3
  int center = paddle_top + 1;
  int offset = hit_y - center; // -1,0,+1 (usually)
  offset = clampi(offset, -1, 1);

  // Add a tiny chance of randomness to keep it from becoming too perfect
  if (random(0, 12) == 0) {
    offset = clampi(offset + (random(0, 2) ? 1 : -1), -1, 1);
  }

  vy = offset;
}

static void ai_move_paddles() {
  // Simple AI with reaction + occasional mistakes.
  // Each paddle can move at most 1 pixel per frame, and sometimes "hesitates".

  // Left AI
  {
    int target = ball_y - 1; // aim center of paddle at ball
    int desired = clampi(target, 0, H - PADDLE_H);

    // 80% of frames: chase; 20%: do nothing
    if (random(0, 10) < 8) {
      if (lp_y < desired) lp_y++;
      else if (lp_y > desired) lp_y--;
    } else {
      // 1/10 chance: move wrong way
      if (random(0, 10) == 0) lp_y += (random(0, 2) ? 1 : -1);
    }
    lp_y = clampi(lp_y, 0, H - PADDLE_H);
  }

  // Right AI
  {
    int target = ball_y - 1;
    int desired = clampi(target, 0, H - PADDLE_H);

    if (random(0, 10) < 8) {
      if (rp_y < desired) rp_y++;
      else if (rp_y > desired) rp_y--;
    } else {
      if (random(0, 10) == 0) rp_y += (random(0, 2) ? 1 : -1);
    }
    rp_y = clampi(rp_y, 0, H - PADDLE_H);
  }
}

static void tick_game() {
  if (in_point_pause) {
    if (millis() >= pause_until_ms) {
      in_point_pause = false;
    }
    return;
  }

  ai_move_paddles();

  int next_x = ball_x + vx;
  int next_y = ball_y + vy;

  // Top/bottom bounce
  if (next_y < 0) {
    next_y = 0;
    vy = -vy;
  } else if (next_y >= H) {
    next_y = H - 1;
    vy = -vy;
  }

  // Paddle collisions / scoring
  if (vx < 0) {
    // Approaching left
    if (next_x == LEFT_X) {
      if (paddle_hits_left(next_x, next_y)) {
        vx = 1;
        adjust_vy_on_hit(lp_y, next_y);
        next_x = ball_x + vx;
        next_y = ball_y + vy;
      } else {
        point_scored(+1); // right scored
        return;
      }
    }
  } else {
    // Approaching right
    if (next_x == RIGHT_X) {
      if (paddle_hits_right(next_x, next_y)) {
        vx = -1;
        adjust_vy_on_hit(rp_y, next_y);
        next_x = ball_x + vx;
        next_y = ball_y + vy;
      } else {
        point_scored(-1); // left scored
        return;
      }
    }
  }

  // Apply
  ball_x = clampi(next_x, 0, W - 1);
  ball_y = clampi(next_y, 0, H - 1);
}

static void render_frame() {
  clear_grid();

  if (in_point_pause) {
    // Flash the scorer side
    if (last_scorer < 0) {
      for (int y = 0; y < H; y++) for (int x = 0; x < W/2; x++) grid[y][x] = 1;
    } else {
      for (int y = 0; y < H; y++) for (int x = W/2; x < W; x++) grid[y][x] = 1;
    }
    // Add a separator line
    draw_center_net();
    render();
    return;
  }

  draw_center_net();
  draw_paddles();
  draw_ball();
  render();
}

void setup() {
  matrix.begin();

  // Seed RNG
  randomSeed((uint32_t)micros());

  // Start with a random serve direction
  reset_ball(random(0, 2) ? 1 : -1);

  last_tick_ms = millis();
}

void loop() {
  uint32_t now = millis();
  if (now - last_tick_ms >= FRAME_MS) {
    last_tick_ms = now;
    tick_game();
    render_frame();
  } else {
    // tiny delay to reduce CPU
    delay(1);
  }
}
