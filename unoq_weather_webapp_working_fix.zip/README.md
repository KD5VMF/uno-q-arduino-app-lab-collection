# UNO Q Weather Dashboard for Arduino App Lab

This shareable version keeps Wi-Fi setup out of the app and adds a built-in API key editor plus a dropdown theme chooser.

## Included

- `app.yaml` - App Lab manifest
- `python/main.py` - Linux-side weather web server
- `sketch/sketch.ino` - optional MCU sketch
- `sketch/sketch.yaml` - App Lab sketch profile
- `config.json` - app settings
- `data/` - runtime cache, usage, and history files

## First run

1. Import the ZIP into Arduino App Lab.
2. Click **Run**.
3. Open `http://<uno-q-ip>:8080`
4. If no API key is set yet, the app opens the **Settings** page automatically.
5. Get a key from **weatherapi.com**, paste it in, save, then return to the dashboard.

## Notes

- No Wi-Fi SSID or password is stored in this project.
- The UNO Q uses whatever network it is already connected to.
- Default refresh is **30 seconds**.
- Ten built-in themes are included and can be selected from a dropdown.


Updated build notes:
- Dashboard forces a fresh API pull when cached data is older than the selected refresh interval.
- Settings include LED matrix IP-scroll brightness (saved in config for shared installs).


Notes:
- This build fixes the auto-refresh 404 by handling query strings correctly.
- The matrix sketch now actually scrolls the connection string on the built-in LED matrix.
- LED brightness in this build is compile-time in sketch/sketch.ino because there is not yet a runtime Linux-to-sketch bridge.
